<?php

namespace App\Http\Controllers;

use PDF;
use App\User;
use App\Client;
use App\Invoice;
use App\Payment;
use Illuminate\Http\Request;
use App\PaymentGatewayConfig;
use App\Exports\PaymentExport;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Session;
use App\Http\Requests\StorePaymentConfig;
use Illuminate\Support\Facades\Hash;
use DB;
use Mail;
use App\Mail\SendUserMail;

use DataTables;

class ClientController extends Controller
{
    private $login;
    private $userId;
    private $userType;
    private $roleId;
    public function __construct()
    {
        //$this->middleware('auth');
    }
    
    public function mail()
    {
        $saveMainIDData = DB::table('clients')->insert(
            [
            	'advisor_id' => $advisor_id, 
            	'first_name' => $first_name, 
            	'last_name' => $last_name, 
            	'email' => $email, 
            	'date_of_birth' => $date_of_birth, 
            	'retirement_age' => $retirement_age, 
            	'gender' => $gender, 
            	'marital_status' => $marital_status, 
            	'client_type' => $client_type, 
            	'capture_user_id' => $capture_user_id, 
            	'client_reference_id' => $client_reference_id, 
            	'user_id' => $user_id, 
            ]);
        
    }
    public function clientListAjax(Request $request)
    {
       if ($request->ajax()) {
            $clients = DB::select("SELECT * FROM `clients` where client_type =  'Main Client' ");
            return Datatables::of($clients)
                    ->addIndexColumn()
                    ->addColumn('action', function($row) {
                           $btn = '<a data-rowid="'.$row->id.'" href="https://fna.phpapplord.co.za/public/overview/'.$row->client_reference_id.'/Main Client" ><i class="fa fa-eye"></i></a>';
                           $btn .= '<a data-rowid="'.$row->id.'" href="https://fna.phpapplord.co.za/public/clientEdit/'.$row->client_reference_id.'" ><i class="fa fa-edit"></i></a>';
                           $btn = $btn.'<a href="https://fna.phpapplord.co.za/public/clientDelete/'.$row->client_reference_id.'"><i class="fa fa-trash-can"></i></a>';
                           return $btn;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }
        return view('clients.clientList');
        
       
    }
    
    public function activeAccount($id,$token)  
    {
        $id = base64_decode($id);
        $usersActivationData = DB::select("SELECT * FROM `users_activation` where user_id = '$id' and remember_token = '$token'");
        if(!empty($usersActivationData))
        {
           
            $active_data =$usersActivationData[0]->date_time;
            $current_time = now();
            $diff = strtotime($current_time) - strtotime($active_data);
            $fullDays    = floor($diff/(60*60*24));   
            $fullHours   = floor(($diff-($fullDays*60*60*24))/(60*60));   
            $fullMinutes = floor(($diff-($fullDays*60*60*24)-($fullHours*60*60))/60);      
            if($fullMinutes <= 60)
            {
                DB::table('users')->where('id', $id)->update(['active_status' =>'1']);
                DB::select("Delete FROM users_activation where user_id = '$id' ");
                 echo "account active";
            }
            else
            {
                echo "link is expired";
            }
        }
        die;
    }
    public function csvClientStore()
    {
        
        session_start();
        if(empty($_SESSION['login']))
        {
            header("location: http://fna.phpapplord.co.za/public/");
            exit;
        }
        $userId = $_SESSION['userId'];
        $allowed = array('csv');

        $filename = $_FILES['upload']['name'];

        $ext = pathinfo($filename, PATHINFO_EXTENSION);

        $clientInfo = array();
        $clientReference = "";

        if (in_array($ext, $allowed)) {
            $handle = fopen($_FILES['upload']['tmp_name'], "r");
           
    		$headers = fgetcsv($handle, 1000, ",");

    		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) 
    		{
    		    $clientInfo[] = $data;
    		}

            fclose($handle);
            foreach($clientInfo as $client_info)
            {
                if($client_info[0] == "Main client")
                {
                    $clientNumber = DB::select("SELECT * FROM clientNumbering order by id desc");

                    if(empty($clientNumber))
                    {
                        $new_client_reference = "fna000000001";
                    }
                    else
                    {
            
                        $count = $clientNumber[0]->num + 1;
                        DB::table('clientNumbering')->insert([
                            'id' => null,
                            'num' => $count,
                        ]);
                        $dbId = strlen($count);
                        $calculate = 12 - $dbId;
                        //echo $calculate;
                        $myzeros = "";
                        for($i = 0; $i < $calculate; $i++)
                        {
                           $myzeros .= "0";
                        }
                        $new_client_reference = "fna".$myzeros.$count;
                    } 
                    $clientReference = $new_client_reference;
                    $client_reference_id = $clientReference;
                    $advisor_id = $userId;
                    //print_r("<pre>"); var_dump($_POST); die(); 
                    $main_first_name = $client_info[1];
                    $main_last_name = $client_info[2];
                    $main_email = $client_info[3];
                    $main_birth_day = $client_info[4];
                    $main_retirement_age = $client_info[5];
                    $main_gender ="none";
                    $main_marital_status = $client_info[6];
                    $main_client_type = $client_info[0];
                    $capture_user_id = $userId;
                    $main_id_number = $client_info[7];;
                    $main_phone =  $client_info[8];
                    // $main_password = md5($main_first_name.'-'.$main_last_name);
                    $main_password = Hash::make('123456');
            
                    //echo "INSERT into clients (advisor_id, first_name, last_name, date_of_birth, retirement_age, gender, marital_status, client_type, capture_user_id, client_reference_id) values ('$advisor_id', '$main_first_name', '$main_last_name', '$main_birth_day', '$main_retirement_age', '$main_gender', '$main_marital_status', '$main_client_type', '$capture_user_id', '$client_reference_id')"; die();
                    //$saveMainData = DB::select("INSERT into clients (advisor_id, first_name, last_name,email, date_of_birth, retirement_age, gender, marital_status, client_type, capture_user_id, client_reference_id) values ('$advisor_id', '$main_first_name', '$main_last_name', '$main_email','$main_birth_day', '$main_retirement_age', '$main_gender', '$main_marital_status', '$main_client_type', '$capture_user_id', '$client_reference_id')");
                    $lastUserMainID = DB::table('users')->insertGetId(
                    [
                        'email' => $main_email, 
                        'password'=>$main_password,
                        'name' => $main_first_name, 
                        'surname' => $main_last_name, 
                        'idNumber' => $main_id_number, 
                        'type' => 'Client',
                        'phone' => $main_phone,
                        'gender' => $main_gender,
                        'dob' => $main_birth_day
                    ]);

             

                    $saveMainIDData = DB::table('clients')->insertGetId(
                    [
                        'advisor_id' => $advisor_id, 
                        'first_name'=>$main_first_name,
                        'last_name' => $main_last_name, 
                        'email' => $main_email, 
                        'date_of_birth' => $main_birth_day, 
                        'retirement_age' => $main_retirement_age,
                        'gender' => $main_gender,
                        'marital_status' => $main_marital_status,
                        'client_type' => $main_client_type,
                        'capture_user_id' => $capture_user_id,
                        'client_reference_id' => $client_reference_id
            
                    ]);
              
                    $_SESSION['client_reference_id'] = $client_reference_id;
                    
                }
                if($client_info[0] == "Spouse")
                {

                    $client_reference_id = $_SESSION['client_reference_id'];
                    $advisor_id = $userId;
                    //print_r("<pre>"); var_dump($_POST); die(); 
                    $main_first_name = $client_info[1];
                    $main_last_name = $client_info[2];
                    $main_email = $client_info[3];
                    $main_birth_day = $client_info[4];
                    $main_retirement_age = $client_info[5];
                    $main_gender ="none";
                    $main_marital_status = $client_info[6];
                    $main_client_type = $client_info[0];
                    $capture_user_id = $userId;
                    $main_id_number = $client_info[7];;
                    $main_phone =  $client_info[8];
                    $main_password = Hash::make('123456');
                    //echo "INSERT into clients (advisor_id, first_name, last_name, date_of_birth, retirement_age, gender, marital_status, client_type, capture_user_id, client_reference_id) values ('$advisor_id', '$main_first_name', '$main_last_name', '$main_birth_day', '$main_retirement_age', '$main_gender', '$main_marital_status', '$main_client_type', '$capture_user_id', '$client_reference_id')"; die();
                    //$saveMainData = DB::select("INSERT into clients (advisor_id, first_name, last_name,email, date_of_birth, retirement_age, gender, marital_status, client_type, capture_user_id, client_reference_id) values ('$advisor_id', '$main_first_name', '$main_last_name', '$main_email','$main_birth_day', '$main_retirement_age', '$main_gender', '$main_marital_status', '$main_client_type', '$capture_user_id', '$client_reference_id')");
                    $lastUserMainID = DB::table('users')->insertGetId(
                    [
                        'email' => $main_email, 
                        'password'=>$main_password,
                        'name' => $main_first_name, 
                        'surname' => $main_last_name, 
                        'idNumber' => $main_id_number, 
                        'type' => 'Client',
                        'phone' => $main_phone,
                        'gender' => $main_gender,
                        'dob' => $main_birth_day
                    ]);

                
                    $saveMainIDData = DB::table('clients')->insertGetId(
                    [
                        'advisor_id' => $advisor_id, 
                        'first_name'=>$main_first_name,
                        'last_name' => $main_last_name, 
                        'email' => $main_email, 
                        'date_of_birth' => $main_birth_day, 
                        'retirement_age' => $main_retirement_age,
                        'gender' => $main_gender,
                        'marital_status' => $main_marital_status,
                        'client_type' => $main_client_type,
                        'capture_user_id' => $capture_user_id,
                        'client_reference_id' => $client_reference_id
            
                    ]);

                   
                }
                if($client_info[0] != "Spouse" && $client_info[0] != "Main client")
                {
                    $client_reference_id = $_SESSION['client_reference_id'];
                    // DB::select("INSERT into dependants values (
                    //     null,
                    //     '".$userId."', 
                    //     '".$userId."', 
                    //     '".$client_reference_id."',
                    //     '".$client_info[0]."',
                    //     '".$client_info[1]."', 
                    //     '".$client_info[2]."', 
                    //     '".$client_info[4]."', 
                    //     'none', 
                    //     '".$client_info[5]."')
                    //     ");

                    DB::table('dependants')->insert([
                        'advisor_id' => $userId,
                        'capture_user_id' => $userId,
                        'client_reference_id' => $client_reference_id,
                        'dependant_type' => $client_info[0],
                        'first_name' => $client_info[1],
                        'last_name' => $client_info[2],
                        'date_of_birth' => $client_info[4],
                        'gender' => $client_info[9],
                        'dependant_until_age' => $client_info[5]
                    ]);
                }
            }
        }
        else
        {
            echo "You are uploading wrong File format";
        }
        
    }
    public function clientCreate()  
    {
       
        session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $clientNumber = DB::select("SELECT * FROM clientNumbering order by id desc");
        if(empty($clientNumber))
        {
            $new_client_reference = "fna000000001";
        }
        else
        {

            $count = $clientNumber[0]->num + 1;
            DB::table('clientNumbering')->insert([
                'id' => null,
                'num' => $count,
            ]);
            $dbId = strlen($count);
            $calculate = 12 - $dbId;
            //echo $calculate;
            $myzeros = "";
            for($i = 0; $i < $calculate; $i++)
            {
               $myzeros .= "0";
            }
            $new_client_reference = "fna".$myzeros.$count;
        }
        $userId = $_SESSION['userId'];
        /*
            Define All Modules Names
        */
        $personalInfoModule = 'Personal Information';
        $dependantsModule = 'Dependants';
        $assetsModule = 'Assets';
        $liabilitiesModule = 'Liabilities';
        $personalBudgetModule = 'Personal budget'; 
        $riskModule = 'Risk Objectives';
        $retirementRiskModule = 'Retirement Risks Objectives';
        /*
            Get All Module Ids
        */
        $personalInfoModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$personalInfoModule'");
        $dependantsModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$dependantsModule'");
        $assetsModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$assetsModule'");
        $liabilitiesModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$liabilitiesModule'");
        $personalBudgetModuleModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$personalBudgetModule'");
        $riskModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$riskModule'");
        $retirementRiskModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$retirementRiskModule'");
        // Get Role Id Of User
        $getroleId = DB::select("SELECT * FROM `permissions` where userId = '".$userId."'");
        //var_dump($getroleId); die();
        if(!isset($getroleId[0]->groupId))
        {
            header("location: https://fna.phpapplord.co.za/public/noAccess");
            exit;
        }
        else
        {
            /*
                Get Access Id to get Read/write access or Access Name
            */
            $getAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$personalInfoModuleModuleId[0]->id."'");
            if(!isset($getAclAccessId[0]->accessId))
            {
                header("location: https://fna.phpapplord.co.za/public/noAccess");
                exit;
            }
            $getAccessName = DB::select("SELECT * FROM `access` where id = '".@$getAclAccessId[0]->accessId."'");
            if(!isset($getAccessName[0]->name))
            {
                header("location: https://fna.phpapplord.co.za/public/noAccess");
                exit;
            }
            else
            {
                if($getAccessName[0]->name == "no-access")
                {
                    header("location: https://fna.phpapplord.co.za/public/noAccess");
                    exit;
                }
            }
        
            /*  
                Get Retirement Access For Menu 
            */
            $getretirementRiskAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$retirementRiskModuleModuleId[0]->id."'");
            if(!isset($getretirementRiskAclAccessId[0]->accessId))
            {
                $getretirementRiskAclAccess = "noAccess";
            }
            else
            {
                $getretirementAccessName = DB::select("SELECT * FROM `access` where id = '".@$getretirementRiskAclAccessId[0]->accessId."'");
                if(!isset($getretirementAccessName[0]->name))
                {
                    $getretirementRiskAclAccess = "noAccess";
                    
                }
                else
                {
                    $getretirementRiskAclAccess = "Access";
                }
            }
            
            /*  
                Get Risk Access For Menu
            */
            $getRiskModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$riskModuleModuleId[0]->id."'");
            if(!isset($getRiskModuleAclAccessId[0]->accessId))
            {
                $getRiskModuleModuleIdAclAccess = "noAccess";
                //echo $getRiskModuleModuleIdAclAccess; die();
            }
            else
            {
                $getRiskModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$getRiskModuleAclAccessId[0]->accessId."'");
                if(!isset($getRiskModuleAccessName[0]->name))
                {
                    $getRiskModuleModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $getRiskModuleModuleIdAclAccess = "Access";
                }
            }
            
            
            /*  
                Get Dependant Access For Menu
            */
            $dependantsModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$dependantsModuleModuleId[0]->id."'");
            if(!isset($dependantsModuleAclAccessId[0]->accessId))
            {
                $dependantsModuleModuleIdAclAccess = "noAccess";
                //echo $getRiskModuleModuleIdAclAccess; die();
            }
            else
            {
                $dependantsModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$dependantsModuleAclAccessId[0]->accessId."'");
                if(!isset($dependantsModuleAccessName[0]->name))
                { 
                    $dependantsModuleModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $dependantsModuleModuleIdAclAccess = "Access";
                }
            }
            
            
            /*  
                Get Asset Module Access For Menu
            */
            $assetsModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$assetsModuleModuleId[0]->id."'");
            if(!isset($assetsModuleAclAccessId[0]->accessId))
            {
                $assetsModuleAclAccessIdModuleIdAclAccess = "noAccess";
            }
            else
            {
                $assetsModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$assetsModuleAclAccessId[0]->accessId."'");
                if(!isset($assetsModuleAccessName[0]->name))
                { 
                    $assetsModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $assetsModuleAclAccessIdModuleIdAclAccess = "Access";
                }
            }
            
            
            /*  
                Get Liabilities Module Access For Menu
            */
            $liabilitiesModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$liabilitiesModuleModuleId[0]->id."'");
            if(!isset($liabilitiesModuleAclAccessId[0]->accessId))
            {
                $liabilitiesModuleAclAccessIdModuleIdAclAccess = "noAccess";
                //echo $getRiskModuleModuleIdAclAccess; die();
            }
            else
            {
                $liabilitiesModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$liabilitiesModuleAclAccessId[0]->accessId."'");
                if(!isset($liabilitiesModuleAccessName[0]->name))
                { 
                    $liabilitiesModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $liabilitiesModuleAclAccessIdModuleIdAclAccess = "Access";
                }
            }
            
            /*  
                Get Personal Budjet Module Access For Menu
            */
            $personalBudgetModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$personalBudgetModuleModuleModuleId[0]->id."'");
            if(!isset($personalBudgetModuleAclAccessId[0]->accessId))
            {
                $personalBudgetModuleAclAccessIdModuleIdAclAccess = "noAccess";
            }
            else
            {
                
                $personalBudgetModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$personalBudgetModuleAclAccessId[0]->accessId."'");
                if(!isset($personalBudgetModuleAccessName[0]->name))
                { 
                    $personalBudgetModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $personalBudgetModuleAclAccessIdModuleIdAclAccess = "Access";
                }
            }
            
            /*  
                Get Personal Information Module Access For Menu
            */
            $personalInfoModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$personalInfoModuleModuleId[0]->id."'");
            if(!isset($personalInfoModuleAclAccessId[0]->accessId))
            {
                $personalInfoModuleAclAccessIdModuleIdAclAccess = "noAccess";
            }
            else
            {   
                $personalInfoModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$personalInfoModuleAclAccessId[0]->accessId."'");
                if(!isset($personalInfoModuleAccessName[0]->name))
                { 
                    $personalInfoModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    if($personalInfoModuleAccessName[0]->name == "no-access")
                    {
                        $personalInfoModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    }
                    else
                    {
                        $personalInfoModuleAclAccessIdModuleIdAclAccess = "Access";
                    }
                }
            }
        } 

        $userRole = DB::select("SELECT name FROM `user_groups` WHERE `id` in  (SELECT groupId FROM `permissions` where userId = '".$userId."')");
        // dd($userRole);
        DB::table('audit')->insert([
            'id' => null,
            'user' => $userId,
            'module' => $personalInfoModule,
            'role' => $userRole[0]->name,
            'action' => "Landed on Client Information Create page",
            'date' => DB::raw('now()')
        ]);        
        
        $personal_details = DB::select("SELECT * FROM `personal_details`");
        //$personal_details = DB::select("SELECT * FROM `clients` where userId = '$userId' ");
        return view('clients.clientCreate', ['new_client_reference' => $new_client_reference, 'personal_details' => $personal_details, 'getroleId' => $getroleId,'personalInfoModuleAclAccessIdModuleIdAclAccess'=>$personalInfoModuleAclAccessIdModuleIdAclAccess, '$getretirementRiskAclAccess'=>$getretirementRiskAclAccess, 'personalBudgetModuleAclAccessIdModuleIdAclAccess'=>$personalBudgetModuleAclAccessIdModuleIdAclAccess,'getRiskModuleModuleIdAclAccess'=> $getRiskModuleModuleIdAclAccess, 'dependantsModuleModuleIdAclAccess'=>$dependantsModuleModuleIdAclAccess, 'getretirementRiskAclAccess'=>$getretirementRiskAclAccess, 'assetsModuleAclAccessIdModuleIdAclAccess'=>$assetsModuleAclAccessIdModuleIdAclAccess, 'liabilitiesModuleAclAccessIdModuleIdAclAccess'=>$liabilitiesModuleAclAccessIdModuleIdAclAccess, 'getAccessName'=>$getAccessName]);
    }
    
    
    public function clientDelete($id)  
    {
        session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        
        $userId = $_SESSION['userId'];
        
        $personalInfoModule = 'Personal Information';
        $userRole = DB::select("SELECT name FROM `user_groups` WHERE `id` in  (SELECT groupId FROM `permissions` where userId = '".$userId."')");
        $clientUserData = DB::select("SELECT user_id FROM `clients` where client_reference_id = '$id' ");
        // dd($userRole);
        DB::table('audit')->insert([
            'id' => null,
            'user' => $userId,
            'module' => $personalInfoModule,
            'role' => $userRole[0]->name,
            'action' => "Landed on Client Information Delete page",
            'date' => DB::raw('now()')
        ]);  
        $clientUserId = $clientUserData[0]->user_id;
        DB::select("Delete FROM clients where client_reference_id = '$id' ");
        DB::select("Delete FROM users where id = '$clientUserId' ");
        DB::select("Delete FROM dependants where client_reference_id = '$id' ");
        return redirect()->route('clientList');
    }
    
    public function dependantDelete($id, $ref)  
    {
        session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $userId = $_SESSION['userId'];
        
        $personalInfoModule = 'Personal Information';
        $userRole = DB::select("SELECT name FROM `user_groups` WHERE `id` in  (SELECT groupId FROM `permissions` where userId = '".$userId."')");
        // dd($userRole);
        DB::table('audit')->insert([
            'id' => null,
            'user' => $userId,
            'module' => $personalInfoModule,
            'role' => $userRole[0]->name,
            'action' => "Landed on Dependant delete from Client Information Delete page",
            'date' => DB::raw('now()')
        ]);  
        DB::select("Delete FROM dependants where id = '$id' ");
        return redirect()->route('clientEdit', $ref);
    }
    
    public function clientEdit($id)  
    {
        session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $userId = $_SESSION['userId'];
        /*
            Define All Modules Names
        */
        $personalInfoModule = 'Personal Information';
        $dependantsModule = 'Dependants';
        $assetsModule = 'Assets';
        $liabilitiesModule = 'Liabilities';
        $personalBudgetModule = 'Personal budget'; 
        $riskModule = 'Risk Objectives';
        $retirementRiskModule = 'Retirement Risks Objectives';
        /*
            Get All Module Ids
        */
        $personalInfoModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$personalInfoModule'");
        $dependantsModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$dependantsModule'");
        $assetsModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$assetsModule'");
        $liabilitiesModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$liabilitiesModule'");
        $personalBudgetModuleModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$personalBudgetModule'");
        $riskModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$riskModule'");
        $retirementRiskModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$retirementRiskModule'");
        // Get Role Id Of User
        $getroleId = DB::select("SELECT * FROM `permissions` where userId = '".$userId."'");
        //var_dump($getroleId); die();
        if(!isset($getroleId[0]->groupId))
        {
            header("location: https://fna.phpapplord.co.za/public/noAccess");
            exit;
        }
        else
        {
            /*
                Get Access Id to get Read/write access or Access Name
            */
            $getAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$personalInfoModuleModuleId[0]->id."'");
            if(!isset($getAclAccessId[0]->accessId))
            {
                header("location: https://fna.phpapplord.co.za/public/noAccess");
                exit;
            }
            $getAccessName = DB::select("SELECT * FROM `access` where id = '".@$getAclAccessId[0]->accessId."'");
            if(!isset($getAccessName[0]->name))
            {
                header("location: https://fna.phpapplord.co.za/public/noAccess");
                exit;
            }
            else
            {
                if($getAccessName[0]->name == "no-access")
                {
                    header("location: https://fna.phpapplord.co.za/public/noAccess");
                    exit;
                }
            }
        
            /*  
                Get Retirement Access For Menu 
            */
            $getretirementRiskAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$retirementRiskModuleModuleId[0]->id."'");
            if(!isset($getretirementRiskAclAccessId[0]->accessId))
            {
                $getretirementRiskAclAccess = "noAccess";
            }
            else
            {
                $getretirementAccessName = DB::select("SELECT * FROM `access` where id = '".@$getretirementRiskAclAccessId[0]->accessId."'");
                if(!isset($getretirementAccessName[0]->name))
                {
                    $getretirementRiskAclAccess = "noAccess";
                    
                }
                else
                {
                    $getretirementRiskAclAccess = "Access";
                }
            }
            
            /*  
                Get Risk Access For Menu
            */
            $getRiskModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$riskModuleModuleId[0]->id."'");
            if(!isset($getRiskModuleAclAccessId[0]->accessId))
            {
                $getRiskModuleModuleIdAclAccess = "noAccess";
                //echo $getRiskModuleModuleIdAclAccess; die();
            }
            else
            {
                $getRiskModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$getRiskModuleAclAccessId[0]->accessId."'");
                if(!isset($getRiskModuleAccessName[0]->name))
                {
                    $getRiskModuleModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $getRiskModuleModuleIdAclAccess = "Access";
                }
            }
            
            
            /*  
                Get Dependant Access For Menu
            */
            $dependantsModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$dependantsModuleModuleId[0]->id."'");
            if(!isset($dependantsModuleAclAccessId[0]->accessId))
            {
                $dependantsModuleModuleIdAclAccess = "noAccess";
                //echo $getRiskModuleModuleIdAclAccess; die();
            }
            else
            {
                $dependantsModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$dependantsModuleAclAccessId[0]->accessId."'");
                if(!isset($dependantsModuleAccessName[0]->name))
                { 
                    $dependantsModuleModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $dependantsModuleModuleIdAclAccess = "Access";
                }
            }
            
            
            /*  
                Get Asset Module Access For Menu
            */
            $assetsModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$assetsModuleModuleId[0]->id."'");
            if(!isset($assetsModuleAclAccessId[0]->accessId))
            {
                $assetsModuleAclAccessIdModuleIdAclAccess = "noAccess";
            }
            else
            {
                $assetsModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$assetsModuleAclAccessId[0]->accessId."'");
                if(!isset($assetsModuleAccessName[0]->name))
                { 
                    $assetsModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $assetsModuleAclAccessIdModuleIdAclAccess = "Access";
                }
            }
            
            
            /*  
                Get Liabilities Module Access For Menu
            */
            $liabilitiesModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$liabilitiesModuleModuleId[0]->id."'");
            if(!isset($liabilitiesModuleAclAccessId[0]->accessId))
            {
                $liabilitiesModuleAclAccessIdModuleIdAclAccess = "noAccess";
                //echo $getRiskModuleModuleIdAclAccess; die();
            }
            else
            {
                $liabilitiesModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$liabilitiesModuleAclAccessId[0]->accessId."'");
                if(!isset($liabilitiesModuleAccessName[0]->name))
                { 
                    $liabilitiesModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $liabilitiesModuleAclAccessIdModuleIdAclAccess = "Access";
                }
            }
            
            /*  
                Get Personal Budjet Module Access For Menu
            */
            $personalBudgetModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$personalBudgetModuleModuleModuleId[0]->id."'");
            if(!isset($personalBudgetModuleAclAccessId[0]->accessId))
            {
                $personalBudgetModuleAclAccessIdModuleIdAclAccess = "noAccess";
            }
            else
            {
                
                $personalBudgetModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$personalBudgetModuleAclAccessId[0]->accessId."'");
                if(!isset($personalBudgetModuleAccessName[0]->name))
                { 
                    $personalBudgetModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $personalBudgetModuleAclAccessIdModuleIdAclAccess = "Access";
                }
            }
            
            /*  
                Get Personal Information Module Access For Menu
            */
            $personalInfoModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$personalInfoModuleModuleId[0]->id."'");
            if(!isset($personalInfoModuleAclAccessId[0]->accessId))
            {
                $personalInfoModuleAclAccessIdModuleIdAclAccess = "noAccess";
            }
            else
            {   
                $personalInfoModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$personalInfoModuleAclAccessId[0]->accessId."'");
                if(!isset($personalInfoModuleAccessName[0]->name))
                { 
                    $personalInfoModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    if($personalInfoModuleAccessName[0]->name == "no-access")
                    {
                        $personalInfoModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    }
                    else
                    {
                        $personalInfoModuleAclAccessIdModuleIdAclAccess = "Access";
                    }
                }
            }
        } 
        
        
        $userRole = DB::select("SELECT name FROM `user_groups` WHERE `id` in  (SELECT groupId FROM `permissions` where userId = '".$userId."')");
        // dd($userRole);
        DB::table('audit')->insert([
            'id' => null,
            'user' => $userId,
            'module' => $personalInfoModule,
            'role' => $userRole[0]->name,
            'action' => "Landed on Client Information Edit page",
            'date' => DB::raw('now()')
        ]);
        
        $personal_details = DB::select("SELECT * FROM `personal_details`");
        //$main_client = DB::select("SELECT * FROM `clients` where client_type = 'Main Spouse' or  client_type = 'Main Client' and client_reference_id = '$id' ");
        $main_client = DB::select("SELECT * FROM `clients` where client_type = 'Main Client' and client_reference_id = '$id' ");
        
        $the_user_id= $main_client[0]->user_id;
        $userObj = DB::select("SELECT * FROM `users` where id ='$the_user_id' ");
        
        $spouse = DB::select("SELECT * FROM `clients` where client_type = 'Spouse' and client_reference_id = '$id' ");
        $the_spouse_user_id= $spouse[0]->user_id;
        $userSpouseObj = DB::select("SELECT * FROM `users` where id ='$the_spouse_user_id' ");
        
        $dependants = DB::select("SELECT * FROM `dependants` where client_reference_id = '$id' ");
        //var_dump($dependants); die();
        return view('clients.clientEdit', ['userObj'=>$userObj,'userSpouseObj'=>$userSpouseObj,'client_reference_id' => $id,'dependant' => $dependants,'spouse' => $spouse, 'main_client' => $main_client, 'personal_details' => $personal_details, 'getroleId' => $getroleId,'personalInfoModuleAclAccessIdModuleIdAclAccess'=>$personalInfoModuleAclAccessIdModuleIdAclAccess, '$getretirementRiskAclAccess'=>$getretirementRiskAclAccess, 'personalBudgetModuleAclAccessIdModuleIdAclAccess'=>$personalBudgetModuleAclAccessIdModuleIdAclAccess,'getRiskModuleModuleIdAclAccess'=> $getRiskModuleModuleIdAclAccess, 'dependantsModuleModuleIdAclAccess'=>$dependantsModuleModuleIdAclAccess, 'getretirementRiskAclAccess'=>$getretirementRiskAclAccess, 'assetsModuleAclAccessIdModuleIdAclAccess'=>$assetsModuleAclAccessIdModuleIdAclAccess, 'liabilitiesModuleAclAccessIdModuleIdAclAccess'=>$liabilitiesModuleAclAccessIdModuleIdAclAccess, 'getAccessName'=>$getAccessName]);
    }
    
    
    
    public function clientSave(Request $request)  
    {
        session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $userId = $_SESSION['userId'];
        // print_r($_POST);
        $personalInfoModule = 'Personal Information';
        $userRole = DB::select("SELECT name FROM `user_groups` WHERE `id` in  (SELECT groupId FROM `permissions` where userId = '".$userId."')");
        // dd($userRole);
        DB::table('audit')->insert([
            'id' => null,
            'user' => $userId,
            'module' => $personalInfoModule,
            'role' => $userRole[0]->name,
            'action' => "Landed on Client Information Save page",
            'date' => DB::raw('now()')
        ]); 
        $client_reference_id = $_POST["client_reference_id"];
        $advisor_id = $userId;
        //print_r("<pre>"); var_dump($_POST); die(); 
        $main_first_name = $_POST["main_first_name"];
        $main_last_name = $_POST["main_last_name"];
        $main_email = $_POST["main_email"];
        $main_birth_day = $_POST["main_day"]."-".$_POST["main_month"]."-".$_POST["main_year"];
        $main_retirement_age = $_POST["main_retirement_age"];
        $main_gender = $_POST["main_gender"];
        $main_marital_status = $_POST["main_marital_status"];
        $main_client_type = "Main Client";
        $capture_user_id = $userId;
        $main_id_number = $_POST["main_idNo"];
        $main_phone = $_POST["main_phone"];
        $main_password = md5($main_first_name.'-'.$main_last_name);
        //echo "INSERT into clients (advisor_id, first_name, last_name, date_of_birth, retirement_age, gender, marital_status, client_type, capture_user_id, client_reference_id) values ('$advisor_id', '$main_first_name', '$main_last_name', '$main_birth_day', '$main_retirement_age', '$main_gender', '$main_marital_status', '$main_client_type', '$capture_user_id', '$client_reference_id')"; die();
        //$saveMainData = DB::select("INSERT into clients (advisor_id, first_name, last_name,email, date_of_birth, retirement_age, gender, marital_status, client_type, capture_user_id, client_reference_id) values ('$advisor_id', '$main_first_name', '$main_last_name', '$main_email','$main_birth_day', '$main_retirement_age', '$main_gender', '$main_marital_status', '$main_client_type', '$capture_user_id', '$client_reference_id')");
        $lastUserMainID = DB::table('users')->insertGetId(
        [
            'email' => $main_email, 
            'password'=>$main_password,
            'name' => $main_first_name, 
            'surname' => $main_last_name, 
            'idNumber' => $main_id_number, 
            'type' => 'Client',
            'phone' => $main_phone,
            'gender' => $main_gender,
            'dob' => $main_birth_day
        ]);
        $saveMainIDData = DB::table('clients')->insertGetId(
        [
            'advisor_id' => $advisor_id, 
            'first_name'=>$main_first_name,
            'last_name' => $main_last_name, 
            'email' => $main_email, 
            'date_of_birth' => $main_birth_day, 
            'retirement_age' => $main_retirement_age,
            'gender' => $main_gender,
            'marital_status' => $main_marital_status,
            'client_type' => $main_client_type,
            'capture_user_id' => $capture_user_id,
            'client_reference_id' => $client_reference_id

        ]);
        //$lastUserMainID = DB::select("INSERT into users (email, password, name,surname, idNumber, type, phone, gender, dob) values ('$main_email','$main_password','$main_first_name','$main_last_name','','Client','','$main_gender','$main_birth_day')");
        
        
        if(!empty($saveMainIDData))
        {
            
            DB::table('clients')->where('id', $saveMainIDData)->update(['user_id' => $lastUserMainID]);
            $active_string = $this::generateRandomString();
            $saveUsersActivationData = DB::table('users_activation')->insertGetId(
            [
                'user_id' => $saveMainIDData, 
                'remember_token'=>$active_string,
                'date_time' => DB::raw('now()')
    
            ]);

            if(!empty($saveUsersActivationData))
            {
                $activation_link = '<a href="'.url('/active_account/'.base64_encode($lastUserMainID).'/'.$active_string).'">Click here</a>';                 
                $mailData = [
                    'title' => 'Please activate your account',
                    'name' => $main_first_name.' '.$main_last_name,
                    'link' =>$activation_link
                ];
                
                $welcomeEmailSent = Mail::to($main_email)->send(new SendUserMail($mailData));
                
                if($welcomeEmailSent instanceof \Illuminate\Mail\SentMessage){
                  echo "Email is sent successfully.";
                }else{
                  echo "Email not sent successfully.";
                }
            }
        }
        
        $advisor_id = $userId;
        $spouse_first_name = $_POST["spouse_first_name"];
        $spouse_last_name = $_POST["spouse_last_name"];
        $spouse_email = $_POST["spouse_email"];
        $spouse_birth_day = $_POST["spouse_day"]."-".$_POST["spouse_month"]."-".$_POST["spouse_year"];
        $spouse_retirement_age = $_POST["spouse_retirement_age"];
        $spouse_gender = $_POST["spouse_gender"];
        $spouse_marital_status = $_POST["spouse_marital_status"];
        $spouse_client_type = "Spouse";
        $capture_user_id = $userId;
        $spouse_password = md5($spouse_first_name.'-'.$spouse_last_name);
        $spouse_id_number = $_POST["spouse_idNo"];
        $spouse_phone = $_POST["spouse_phone"];
        
        //echo "INSERT into clients (advisor_id, first_name, last_name, date_of_birth, retirement_age, gender, marital_status, client_type, capture_user_id, client_reference_id) values ('$advisor_id', '$main_first_name', '$main_last_name', '$main_birth_day', '$main_retirement_age', '$main_gender', '$main_marital_status', '$main_client_type', '$capture_user_id', '$client_reference_id')"; die();
        //$saveSpouseData = DB::select("INSERT into clients (advisor_id, first_name, last_name,email, date_of_birth, retirement_age, gender, marital_status, client_type, capture_user_id, client_reference_id) values ('$advisor_id', '$spouse_first_name', '$spouse_last_name','$spouse_email' ,'$spouse_birth_day', '$spouse_retirement_age', '$spouse_gender', '$spouse_marital_status', '$spouse_client_type', '$capture_user_id', '$client_reference_id')");

        $saveSpouseIDData = DB::table('clients')->insertGetId(
        [
            'advisor_id' => $advisor_id, 
            'first_name'=>$spouse_first_name,
            'last_name' => $spouse_last_name, 
            'email' => $spouse_email, 
            'date_of_birth' => $spouse_birth_day, 
            'retirement_age' => $spouse_retirement_age,
            'gender' => $spouse_gender,
            'marital_status' => $spouse_marital_status,
            'client_type' => $spouse_client_type,
            'capture_user_id' => $capture_user_id,
            'client_reference_id' => $client_reference_id

        ]);
        
        //$saveSpouseUserData = DB::select("INSERT into users (email, password, name,surname, idNumber, type, phone, gender, dob) values ('$spouse_email','$spouse_password','$spouse_first_name','$spouse_last_name','','Client','','$spouse_gender','$spouse_birth_day')");
        $lastUserSpouseID = DB::table('users')->insertGetId(
        [
            'email' => $spouse_email, 
            'password'=>$spouse_password,
            'name' => $spouse_first_name, 
            'surname' => $spouse_last_name, 
            'idNumber' => $spouse_id_number, 
            'type' => 'Client',
            'phone' => $spouse_phone,
            'gender' => $spouse_gender,
            'dob' => $spouse_birth_day
        ]);
        
        if(!empty($lastUserSpouseID))
        {
            DB::table('clients')->where('id', $saveSpouseIDData)->update(['user_id' => $lastUserSpouseID]);
        }
        $count = count($_POST['dependant_type']); 
        for($j = 0; $j < $count; $j++)
        { 
            DB::select("INSERT into dependants values (
                null,
                '".$userId."', 
                '".$userId."', 
                '".$client_reference_id."',
                '".$_POST['dependant_type'][$j]."',
                '".$_POST['dependant_first_name'][$j]."', 
                '".$_POST['dependant_last_name'][$j]."', 
                '".$_POST['dependant_year'][$j]."-".$_POST['dependant_month'][$j]."-".$_POST['dependant_day'][$j]."', 
                '".$_POST['dependant_gender'][$j]."', 
                '".$_POST['dependant_age'][$j]."')
                ");
        }
        return redirect()->route('clientList');
    }
    
    function generateRandomString($length = 10) {
        
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
        
    }
    
    public function clientUpdate(Request $request)  
    {
        //  var_dump($_POST);
        // die();
        session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $userId = $_SESSION['userId'];
        
        $personalInfoModule = 'Personal Information';
        $userRole = DB::select("SELECT name FROM `user_groups` WHERE `id` in  (SELECT groupId FROM `permissions` where userId = '".$userId."')");
        // dd($userRole);
        DB::table('audit')->insert([
            'id' => null,
            'user' => $userId,
            'module' => $personalInfoModule,
            'role' => $userRole[0]->name,
            'action' => "Landed on Client Information Update page",
            'date' => DB::raw('now()')
        ]);         
        
        $advisor_id = $userId;
        //print_r("<pre>"); var_dump($_POST); die(); 
        $main_first_name = $_POST["main_first_name"];
        $main_last_name = $_POST["main_last_name"];
        $main_birth_day = $_POST["main_day"]."-".$_POST["main_month"]."-".$_POST["main_year"];
        $main_retirement_age = $_POST["main_retirement_age"];
        $main_gender = $_POST["main_gender"];
        $main_marital_status = $_POST["main_marital_status"];
        $main_client_type = "Main Client";
        $capture_user_id = $userId; 
        $client_reference_id = $_POST["client_reference_id"];
        $main_id_number = $_POST["main_idNo"];
        $main_phone = $_POST["main_phone"];
        $main_user_id = $_POST['main_user_id'];
        //echo "update clients set first_name = '$main_first_name' , last_name = '$main_last_name' , date_of_birth = '$main_birth_day' , retirement_age = '$main_retirement_age' , marital_status = '$main_marital_status' where client_reference_id = '$client_reference_id' and client_type = 'Main Client'"; die();
        $saveData = DB::select("update clients set 
                        first_name = '$main_first_name' , 
                        last_name = '$main_last_name' , 
                        date_of_birth = '$main_birth_day' , 
                        retirement_age = '$main_retirement_age' , 
                        gender = '$main_gender' , 
                        marital_status = '$main_marital_status'
                        where 
                        user_id = '$main_user_id'");
        
        $saveUserData = DB::select("update users set 
                        name = '$main_first_name' , 
                        surname = '$main_last_name' , 
                        idNumber = '$main_id_number' , 
                        phone = '$main_phone' , 
                        gender = '$main_gender' , 
                        dob = '$main_birth_day'
                        where 
                        id = '$main_user_id'");
        
        $advisor_id = $userId;
        $spouse_first_name = $_POST["spouse_first_name"];
        $spouse_last_name = $_POST["spouse_last_name"];
        $spouse_birth_day = $_POST["spouse_day"]."-".$_POST["spouse_month"]."-".$_POST["spouse_year"];
        $spouse_retirement_age = $_POST["spouse_retirement_age"];
        $spouse_gender = $_POST["spouse_gender"];
        $spouse_marital_status = $_POST["spouse_marital_status"];
        $spouse_client_type = "Spouse";
        $capture_user_id = $userId;
        $client_reference_id = $_POST["client_reference_id"];
        
        $spouse_id_number = $_POST["spouse_idNo"];
        $spouse_phone = $_POST["spouse_phone"];
        $spouse_user_id = $_POST["spouse_user_id"];
        //echo "update clients set first_name = '$spouse_first_name' , last_name = '$spouse_last_name' , date_of_birth = '$spouse_birth_day' , retirement_age = '$spouse_retirement_age' , marital_status = '$spouse_marital_status' where client_reference_id = '$client_reference_id' and client_type = 'Spouse'"; die();
        DB::select("update clients set 
        first_name = '$spouse_first_name' , 
        last_name = '$spouse_last_name' , 
        date_of_birth = '$spouse_birth_day' , 
        retirement_age = '$spouse_retirement_age' , 
        marital_status = '$spouse_marital_status'
        where user_id = '$spouse_user_id'");
        
        $saveSpouseUserData = DB::select("update users set 
                        name = '$spouse_first_name' , 
                        surname = '$spouse_last_name' , 
                        idNumber = '$spouse_id_number' , 
                        phone = '$spouse_phone' , 
                        gender = '$spouse_gender' , 
                        dob = '$spouse_birth_day' 
                        where 
                        id = '$spouse_user_id'");
        if(isset($_POST['dependant_type']))
        {
            $count = count($_POST['dependant_type']); 
            if($count > 0){
             for($j = 0; $j < $count; $j++)
                { 
                    if(isset($_POST['dependant_id'][$j]))
                    {
                        DB::select("update dependants set
                        dependant_type = '".$_POST['dependant_type'][$j]."',
                        first_name = '".$_POST['dependant_first_name'][$j]."', 
                        last_name = '".$_POST['dependant_last_name'][$j]."', 
                        date_of_birth = '".$_POST['dependant_year'][$j]."-".$_POST['dependant_month'][$j]."-".$_POST['dependant_day'][$j]."', 
                        gender = '".$_POST['dependant_gender'][$j]."', 
                        dependant_until_age = '".$_POST['dependant_age'][$j]."'
                        where id = '".$_POST['dependant_id'][$j]."'
                        ");
                    }
                    else
                    {
                        DB::select("INSERT into dependants values (
                        null,
                        '".$userId."', 
                        '".$userId."', 
                        '".$client_reference_id."',
                        '".$_POST['dependant_type'][$j]."',
                        '".$_POST['dependant_first_name'][$j]."', 
                        '".$_POST['dependant_last_name'][$j]."', 
                        '".$_POST['dependant_year'][$j]."-".$_POST['dependant_month'][$j]."-".$_POST['dependant_day'][$j]."', 
                        '".$_POST['dependant_gender'][$j]."', 
                        '".$_POST['dependant_age'][$j]."')
                        ");
                    }
                    
                }   
            }
        }
        
        
        return redirect()->route('clientList');
    }
    
    
     public function spouseSave(Request $request)  
    {
        session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $userId = $_SESSION['userId'];
        
        $personalInfoModule = 'Personal Information';
        $userRole = DB::select("SELECT name FROM `user_groups` WHERE `id` in  (SELECT groupId FROM `permissions` where userId = '".$userId."')");
        // dd($userRole);
        DB::table('audit')->insert([
            'id' => null,
            'user' => $userId,
            'module' => $personalInfoModule,
            'role' => $userRole[0]->name,
            'action' => "Landed on Client Information Spouse Save page",
            'date' => DB::raw('now()')
        ]); 
        
        /*
        print_r("<pre>"); var_dump($_POST);
        $advisor_id = $userId;
        $main_first_name = $_POST["main_first_name"];
        $main_last_name = $_POST["main_last_name"];
        $main_birth_day = $_POST["main_day"]."-".$_POST["main_month"]."-".$_POST["main_year"];
        $main_retirement_age = $_POST["main_retirement_age"];
        $main_gender = $_POST["main_gender"];
        $main_marital_status = $_POST["main_marital_status"];
        $main_client_type = "Main Client";
        $capture_user_id = $userId;
        $client_reference_id = 'fna0000001';
        //echo "INSERT into clients (advisor_id, first_name, last_name, date_of_birth, retirement_age, gender, marital_status, client_type, capture_user_id, client_reference_id) values ('$advisor_id', '$main_first_name', '$main_last_name', '$main_birth_day', '$main_retirement_age', '$main_gender', '$main_marital_status', '$main_client_type', '$capture_user_id', '$client_reference_id')"; die();
        DB::select("INSERT into clients (advisor_id, first_name, last_name, date_of_birth, retirement_age, gender, marital_status, client_type, capture_user_id, client_reference_id) values ('$advisor_id', '$main_first_name', '$main_last_name', '$main_birth_day', '$main_retirement_age', '$main_gender', '$main_marital_status', '$main_client_type', '$capture_user_id', '$client_reference_id')");*/
        
        $advisor_id = $userId;
        $spouse_first_name = $_POST["spouse_first_name"];
        $spouse_last_name = $_POST["spouse_last_name"];
        $spouse_birth_day = $_POST["spouse_day"]."-".$_POST["spouse_month"]."-".$_POST["spouse_year"];
        $spouse_retirement_age = $_POST["spouse_retirement_age"];
        $spouse_gender = $_POST["spouse_gender"];
        $spouse_marital_status = $_POST["spouse_marital_status"];
        $spouse_client_type = "Spouse";
        $capture_user_id = $userId;
        $client_reference_id = 'fna0000002';
        //echo "INSERT into clients (advisor_id, first_name, last_name, date_of_birth, retirement_age, gender, marital_status, client_type, capture_user_id, client_reference_id) values ('$advisor_id', '$main_first_name', '$main_last_name', '$main_birth_day', '$main_retirement_age', '$main_gender', '$main_marital_status', '$main_client_type', '$capture_user_id', '$client_reference_id')"; die();
        $saveData = DB::select("INSERT into clients (advisor_id, first_name, last_name, date_of_birth, retirement_age, gender, marital_status, client_type, capture_user_id, client_reference_id) values ('$advisor_id', '$spouse_first_name', '$spouse_last_name', '$spouse_birth_day', '$spouse_retirement_age', '$spouse_gender', '$spouse_marital_status', '$spouse_client_type', '$capture_user_id', '$client_reference_id')");
        return redirect()->route('clientList');  
    }
    public function clientList()
    {
        session_start(); 
        if(empty($_SESSION['login']))
        {             
            header("location: https://fna.phpapplord.co.za/public/");               
            exit;
        } 
        $userId = $_SESSION['userId'];
        

        
        $personalInfoModule = 'Personal Information';
        $dependantsModule = 'Dependants';
        $assetsModule = 'Assets';
        $liabilitiesModule = 'Liabilities';
        $personalBudgetModule = 'Personal budget'; 
        $riskModule = 'Risk Objectives';
        $retirementRiskModule = 'Retirement Risks Objectives'; 
        $personalInfoModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$personalInfoModule'");
        $dependantsModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$dependantsModule'");
        $assetsModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$assetsModule'");
        $liabilitiesModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$liabilitiesModule'");
        $personalBudgetModuleModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$personalBudgetModule'");
        $riskModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$riskModule'");
        $retirementRiskModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$retirementRiskModule'");
        $getroleId = DB::select("SELECT * FROM `permissions` where userId = '".$userId."'");
        if(!isset($getroleId[0]->groupId))
        {
            header("location: https://fna.phpapplord.co.za/public/noAccess");
            exit;
        }
        else
        {
            //var_dump($getroleId[0]->groupId); die();
            $getretirementRiskAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$retirementRiskModuleModuleId[0]->id."'");
            if(!isset($getretirementRiskAclAccessId[0]->accessId))
            {
                $getretirementRiskAclAccess = "noAccess";
               // echo $getretirementRiskAclAccess; die();
            }
            else
            {
                $getretirementAccessName = DB::select("SELECT * FROM `access` where id = '".@$getretirementRiskAclAccessId[0]->accessId."'");
                if(!isset($getretirementAccessName[0]->name))
                {
                    $getretirementRiskAclAccess = "noAccess";
                    
                }
                else
                {
                    $getretirementRiskAclAccess = "Access";
                }
            }
            
            
            $getRiskModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$riskModuleModuleId[0]->id."'");
            if(!isset($getRiskModuleAclAccessId[0]->accessId))
            {
                $getRiskModuleModuleIdAclAccess = "noAccess";
                //echo $getRiskModuleModuleIdAclAccess; die();
            }
            else
            {
                $getRiskModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$getRiskModuleAclAccessId[0]->accessId."'");
                if(!isset($getRiskModuleAccessName[0]->name))
                {
                    $getRiskModuleModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $getRiskModuleModuleIdAclAccess = "Access";
                }
            }
            
            
            
            $dependantsModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$dependantsModuleModuleId[0]->id."'");
            if(!isset($dependantsModuleAclAccessId[0]->accessId))
            {
                $dependantsModuleModuleIdAclAccess = "noAccess";
                //echo $getRiskModuleModuleIdAclAccess; die();
            }
            else
            {
                $dependantsModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$dependantsModuleAclAccessId[0]->accessId."'");
                if(!isset($dependantsModuleAccessName[0]->name))
                { 
                    $dependantsModuleModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $dependantsModuleModuleIdAclAccess = "Access";
                }
            }
            
            
            
            $assetsModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$assetsModuleModuleId[0]->id."'");
            if(!isset($assetsModuleAclAccessId[0]->accessId))
            {
                $assetsModuleAclAccessIdModuleIdAclAccess = "noAccess";
                //echo $getRiskModuleModuleIdAclAccess; die();
            }
            else
            {
                $assetsModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$assetsModuleAclAccessId[0]->accessId."'");
                if(!isset($assetsModuleAccessName[0]->name))
                { 
                    $assetsModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $assetsModuleAclAccessIdModuleIdAclAccess = "Access";
                }
            }
            
            
            
            $liabilitiesModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$liabilitiesModuleModuleId[0]->id."'");
            if(!isset($liabilitiesModuleAclAccessId[0]->accessId))
            {
                $liabilitiesModuleAclAccessIdModuleIdAclAccess = "noAccess";
                //echo $getRiskModuleModuleIdAclAccess; die();
            }
            else
            {
                $liabilitiesModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$liabilitiesModuleAclAccessId[0]->accessId."'");
                if(!isset($liabilitiesModuleAccessName[0]->name))
                { 
                    $liabilitiesModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $liabilitiesModuleAclAccessIdModuleIdAclAccess = "Access";
                }
            }
            
            
            $personalBudgetModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$personalBudgetModuleModuleModuleId[0]->id."'");
            if(!isset($personalBudgetModuleAclAccessId[0]->accessId))
            {
                $personalBudgetModuleAclAccessIdModuleIdAclAccess = "noAccess";
                //echo $getRiskModuleModuleIdAclAccess; die();
            }
            else
            {
                $personalBudgetModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$personalBudgetModuleAclAccessId[0]->accessId."'");
                if(!isset($liabilitiesModuleAccessName[0]->name))
                { 
                    $personalBudgetModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    $personalBudgetModuleAclAccessIdModuleIdAclAccess = "Access";
                }
            }
            
            $personalInfoModuleAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".@$getroleId[0]->groupId."' and moduleId = '".$personalInfoModuleModuleId[0]->id."'");
            if(!isset($personalInfoModuleAclAccessId[0]->accessId))
            {
                $personalInfoModuleAclAccessIdModuleIdAclAccess = "noAccess";
            }
            else
            {   
                $personalInfoModuleAccessName = DB::select("SELECT * FROM `access` where id = '".@$personalInfoModuleAclAccessId[0]->accessId."'");
                if(!isset($personalInfoModuleAccessName[0]->name))
                { 
                    $personalInfoModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    
                }
                else
                {
                    if($personalInfoModuleAccessName[0]->name == "no-access")
                    {
                        $personalInfoModuleAclAccessIdModuleIdAclAccess = "noAccess";
                    }
                    else
                    {
                        $personalInfoModuleAclAccessIdModuleIdAclAccess = "Access";
                    }
                }
            }
            
        }
        $Module = 'Liabilities';
        $getModuleId = DB::select("SELECT * FROM `modules` where name = '$Module'");
        $roleId = DB::select("SELECT * FROM `permissions` where userId = '".$userId."' ");
        $getAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$roleId[0]->groupId."' and moduleId = '".$getModuleId[0]->id."'");
        // var_dump($getAclAccessId); die();
        if(!isset($getAclAccessId[0]->accessId))
        {
            header("location: https://fna.phpapplord.co.za/public/noAccess");
            exit;
        }
        $getAccessName = DB::select("SELECT * FROM `access` where id = '".@$getAclAccessId[0]->accessId."'");
        if(!isset($getAccessName[0]->name))
        {
            header("location: https://fna.phpapplord.co.za/public/noAccess");
            exit;
            
        }
        else
        {
            if($getAccessName[0]->name == "no-access")
            {
                header("location: https://fna.phpapplord.co.za/public/noAccess");
                exit;
            }
        }
        
        $userRole = DB::select("SELECT * FROM `user_groups` WHERE `id` = '".@$roleId[0]->groupId."'");
        // dd($userRole);
            DB::table('audit')->insert([
                'id' => null,
                'user' => $userId,
                'module' => $personalInfoModule,
                'role' => $userRole[0]->name,
                'action' => "Landed on Client List",
                'date' => DB::raw('now()')
            ]);        
        //$clients = DB::select("SELECT * FROM `clients` where client_type = 'Main Spouse' or client_type =  'Main Client' ");
        $clients = DB::select("SELECT * FROM `clients` where client_type =  'Main Client' ");
        return view('clients.clientList', ['getroleId' => $getroleId, 'clients' => $clients, 'personalInfoModuleAclAccessIdModuleIdAclAccess'=>$personalInfoModuleAclAccessIdModuleIdAclAccess, 'getAccessName'=>$getAccessName, 'getAccessName'=>$getAccessName, '$getretirementRiskAclAccess'=>$getretirementRiskAclAccess, 'personalBudgetModuleAclAccessIdModuleIdAclAccess'=>$personalBudgetModuleAclAccessIdModuleIdAclAccess,'getRiskModuleModuleIdAclAccess'=> $getRiskModuleModuleIdAclAccess, 'dependantsModuleModuleIdAclAccess'=>$dependantsModuleModuleIdAclAccess, 'getretirementRiskAclAccess'=>$getretirementRiskAclAccess, 'assetsModuleAclAccessIdModuleIdAclAccess'=>$assetsModuleAclAccessIdModuleIdAclAccess, 'liabilitiesModuleAclAccessIdModuleIdAclAccess'=>$liabilitiesModuleAclAccessIdModuleIdAclAccess]);
    } 
}
?>