<?php

namespace App\Http\Controllers;

use PDF;
use App\User;
use App\Client;
use App\Invoice;
use App\Payment;
use Illuminate\Http\Request;
use App\PaymentGatewayConfig;
use App\Exports\PaymentExport;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Session;
use App\Http\Requests\StorePaymentConfig;
use Illuminate\Support\Facades\Date;
use DB;

class CategoryController extends Controller
{

    private $login;
    private $userId;
    private $userType;
    private $roleId;
    public function __construct()
    {
        //$this->middleware('auth');
    }
    
    public function index() {
        session_start();
        if (empty($_SESSION['login'])) {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $types = DB::select("SELECT * , CASE WHEN income_expense_type = 1 THEN 'Income' ELSE 'Expense' END as type FROM `income_expense_type` ");
        return view('category.listCategory', [
            'types' => $types
        ]);
    }
    public function create() {
        return view('category.createCategory');
    }
    public function edit(Request $request, $id) {
        $types = DB::select("SELECT * , CASE WHEN income_expense_type = 1 THEN 'Income' ELSE 'Expense' END as type FROM `income_expense_type` WHERE id = '".$id."' ");
        return view('category.editCategory', [
            'types' => $types,
            'id' => $id
        ]);
    }   
    public function update(Request $request) {
        $affected = DB::table('income_expense_type')
              ->where('id', $_POST['id'])
              ->update([
                  'income_expense_name' => $_POST['income_expense_name'],
                  'income_expense_type' => $_POST['income_types']      
              ]);
        return \Redirect::route('listIncomeExpenseTypes');

    }   
    public function store() {
        $affected = DB::table('income_expense_type')
          ->insert([
              'income_expense_name' => $_POST['income_expense_name'],
              'income_expense_type' => $_POST['income_types']      
          ]);
        return \Redirect::route('listIncomeExpenseTypes');
    }
    public function delete() {
        $affected = DB::table('income_expense_type')
              ->where('id', $_POST['id'])
              ->delete();
        return \Redirect::route('listIncomeExpenseTypes');
    }     
    
}    