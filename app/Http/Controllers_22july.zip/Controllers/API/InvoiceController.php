<?php

namespace App\Http\Controllers\API;

use App\User;
use App\Proof;
use App\Invoice;
use App\Service;
use App\Payment;
use App\InvoiceReminder;
use Illuminate\Http\Request;
use App\SMSCampaignConfiguration;
use App\EmailCampaignConfiguration;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\Facades\Image as InterventionImage;
use DB;


class InvoiceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $total_amount = 0;
         
        foreach($request->items as $key => $item)
        {
            $itemValue = Service::find($item['name']);

            $total_amount = $total_amount + $itemValue->price * $item['quantity'];
        }

        $user = User::findOrFail($request->userId);
         
        $invoice = new Invoice();
        $invoice->client_id = $request->client;
        $invoice->user_id = $request->userId;
        $invoice->notes = $request->notes;
        $invoice->total_amount = $total_amount;
        $invoice->due_date = $request->dueDate;
        $invoice->companyId = $user->company_id;
        $invoice->save();
        
        $invoiceId = (int) $invoice->id;
        
        $invoice = Invoice::findOrFail($invoiceId);
        $invoiceId = $invoice->getInvoiceId();
        $section = 'Invoice Management';
        $action = "Created Invoice No $invoiceId";
        $userId = $request->userId;
        $getRoles = DB::select("SELECT roles.name, users.name as fullName FROM users inner join permissions on permissions.user_id = users.id inner join roles on permissions.role_id = roles.id where users.id =  $userId");
        $getRolesName = $getRoles[0]->name;
        $getFullname = $getRoles[0]->fullName;
        DB::table('audit')->insert([
                'id' => null,
                'userId' => $userId,
                'name' => $getFullname,
                'role' => $getRolesName,
                'action' => $action,
                'section' => $section,
                'app' => 'Dashboard',
                'date' => DB::raw('now()')
            ]);
            
        $company_email_configs = EmailCampaignConfiguration::where('company_id', $user->company_id)->first();
        $company_sms_configs = SMSCampaignConfiguration::where('company_id', $user->company_id)->first();
        
        if($company_email_configs == null && $company_sms_configs == null){
            $invoice_reminder = new InvoiceReminder();
            $invoice_reminder->due_date = $request->dueDate;
            $invoice_reminder->payment_status = 'Not Paid';
            $invoice_reminder->reminder_status = 'No Reminder';
            $invoice_reminder->invoice_id = $invoice->id;
            $invoice_reminder->save();
        }
        
        if($company_email_configs != null && $company_sms_configs == null)
        {
            $invoice_reminder = new InvoiceReminder();
            $invoice_reminder->due_date = $request->dueDate;
            $invoice_reminder->payment_status = 'Not Paid';
            $invoice_reminder->reminder_status = 'No Reminder';
            $invoice_reminder->is_first_mailreminder_enabled = $company_email_configs->is_1st_reminder_enabled;
            $invoice_reminder->first_mailreminder_template = $company_email_configs->first_rem_template;
            $invoice_reminder->first_mailreminder_days = $company_email_configs->first_rem_days;
            $invoice_reminder->is_second_mailreminder_enabled = $company_email_configs->is_2nd_reminder_enabled;
            $invoice_reminder->second_mailreminder_template = $company_email_configs->second_rem_template;
            $invoice_reminder->second_mailreminder_days = $company_email_configs->second_reminder_days;
            $invoice_reminder->is_mailhandover_enabled = $company_email_configs->is_handover_enabled;
            $invoice_reminder->mail_handover_template = $company_email_configs->handover_template;
            $invoice_reminder->mail_handover_days = $company_email_configs->handover_days;
            $invoice_reminder->is_letter_of_demand_enabled = $company_email_configs->is_letter_of_demand_enabled;
            $invoice_reminder->letter_of_demand_template = $company_email_configs->letter_of_demand_template;
            $invoice_reminder->letter_of_demand_days = $company_email_configs->letter_of_demand_days;
            $invoice_reminder->is_final_notice_enabled = $company_email_configs->is_final_notice_enabled;
            $invoice_reminder->final_notice_template = $company_email_configs->final_notice_template;
            $invoice_reminder->final_notice_days = $company_email_configs->final_notice_days;
            $invoice_reminder->invoice_id = $invoice->id;
            $invoice_reminder->save();
        }

             
        if($company_email_configs == null && $company_sms_configs != null)
        {
            $invoice_reminder = new InvoiceReminder();
            $invoice_reminder->due_date = $request->dueDate;
            $invoice_reminder->payment_status = 'Not Paid';
            $invoice_reminder->reminder_status = 'No Reminder';
            $invoice_reminder->is_first_smsreminder_enabled = $company_sms_configs->is_1st_reminder_enabled;
            $invoice_reminder->first_smsreminder_template = $company_sms_configs->first_rem_template;
            $invoice_reminder->first_smsreminder_days = $company_sms_configs->first_rem_days;
            $invoice_reminder->is_second_smsreminder_enabled = $company_sms_configs->is_2nd_reminder_enabled;
            $invoice_reminder->second_smsreminder_template = $company_sms_configs->second_rem_template;
            $invoice_reminder->second_smsreminder_days = $company_sms_configs->second_reminder_days;
            $invoice_reminder->is_smshandover_enabled = $company_sms_configs->is_handover_enabled;
            $invoice_reminder->sms_handover_template = $company_sms_configs->handover_template;
            $invoice_reminder->sms_handover_days = $company_sms_configs->handover_days;
            $invoice_reminder->is_SMS_letter_of_demand_enabled = $company_sms_configs->is_letter_of_demand_enabled;
            $invoice_reminder->SMS_letter_of_demand_template = $company_sms_configs->letter_of_demand_template;
            $invoice_reminder->SMS_letter_of_demand_days = $company_sms_configs->letter_of_demand_days;
            $invoice_reminder->is_SMS_final_notice_enabled = $company_sms_configs->is_final_notice_enabled;
            $invoice_reminder->SMS_final_notice_template = $company_sms_configs->final_notice_template;
            $invoice_reminder->SMS_final_notice_days = $company_sms_configs->final_notice_days;
            $invoice_reminder->invoice_id = $invoice->id;
            $invoice_reminder->save();
        }


        if($company_email_configs != null && $company_sms_configs != null)
        {
            $invoice_reminder = new InvoiceReminder();
            $invoice_reminder->due_date = $request->dueDate;
            $invoice_reminder->payment_status = 'Not Paid';
            $invoice_reminder->reminder_status = 'No Reminder';
            $invoice_reminder->is_first_mailreminder_enabled = $company_email_configs->is_1st_reminder_enabled;
            $invoice_reminder->first_mailreminder_template = $company_email_configs->first_rem_template;
            $invoice_reminder->first_mailreminder_days = $company_email_configs->first_rem_days;
            $invoice_reminder->is_second_mailreminder_enabled = $company_email_configs->is_2nd_reminder_enabled;
            $invoice_reminder->second_mailreminder_template = $company_email_configs->second_rem_template;
            $invoice_reminder->second_mailreminder_days = $company_email_configs->second_reminder_days;
            $invoice_reminder->is_mailhandover_enabled = $company_email_configs->is_handover_enabled;
            $invoice_reminder->mail_handover_template = $company_email_configs->handover_template;
            $invoice_reminder->mail_handover_days = $company_email_configs->handover_days;
            $invoice_reminder->is_first_smsreminder_enabled = $company_sms_configs->is_1st_reminder_enabled;
            $invoice_reminder->first_smsreminder_template = $company_sms_configs->first_rem_template;
            $invoice_reminder->first_smsreminder_days = $company_sms_configs->first_rem_days;
            $invoice_reminder->is_second_smsreminder_enabled = $company_sms_configs->is_2nd_reminder_enabled;
            $invoice_reminder->second_smsreminder_template = $company_sms_configs->second_rem_template;
            $invoice_reminder->second_smsreminder_days = $company_sms_configs->second_reminder_days;
            $invoice_reminder->is_smshandover_enabled = $company_sms_configs->is_handover_enabled;
            $invoice_reminder->sms_handover_template = $company_sms_configs->handover_template;
            $invoice_reminder->sms_handover_days = $company_sms_configs->handover_days;
            $invoice_reminder->is_letter_of_demand_enabled = $company_email_configs->is_letter_of_demand_enabled;
            $invoice_reminder->letter_of_demand_template = $company_email_configs->letter_of_demand_template;
            $invoice_reminder->letter_of_demand_days = $company_email_configs->letter_of_demand_days;
            $invoice_reminder->is_final_notice_enabled = $company_email_configs->is_final_notice_enabled;
            $invoice_reminder->final_notice_template = $company_email_configs->final_notice_template;
            $invoice_reminder->final_notice_days = $company_email_configs->final_notice_days;
            $invoice_reminder->is_SMS_letter_of_demand_enabled = $company_sms_configs->is_letter_of_demand_enabled;
            $invoice_reminder->SMS_letter_of_demand_template = $company_sms_configs->letter_of_demand_template;
            $invoice_reminder->SMS_letter_of_demand_days = $company_sms_configs->letter_of_demand_days;
            $invoice_reminder->is_SMS_final_notice_enabled = $company_sms_configs->is_final_notice_enabled;
            $invoice_reminder->SMS_final_notice_template = $company_sms_configs->final_notice_template;
            $invoice_reminder->SMS_final_notice_days = $company_sms_configs->final_notice_days;
            $invoice_reminder->invoice_id = $invoice->id;
            $invoice_reminder->save();
        }
        
        
        foreach($request->items as $key => $item)
        {
            $invoice->services()->attach($item['name'], ['item_quantity' => $item['quantity']]);
        }

        return response()->json([
            'invoice' => $invoice
        ], 200);
        

    
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    
   
    public function pend_payment(Request $request)
    {
        
        
        $invoice = Invoice::find($request->id);
        
        //add payment to the ledger
        $payment = Payment::where('invoice_id', '=', $request->id)->where('status', 'Pending')->first();
        
         if($payment)
        {
            return response()->json([
                'message' => 'invoice already paid'
            ],200);
        }

        
         $payment = new Payment();
        $payment->payment_type = 'Cash';
        $payment->status = 'Pending';
        $payment->amount_paid = $invoice->total_amount;
        $payment->client_id = $invoice->client_id;
        $payment->invoice_id = $invoice->id;
        $payment->save();
        
        if($request->image)
        {
           
            $name = time().'.'. explode('/', explode(':', substr($request->image, 0, strpos($request->image, ';')))[1])[1];
            InterventionImage::make($request->image)->save(public_path('images/proof_payments/').$name);

            $path = $name;

            $proof = new Proof();
            $proof->path = 'proof_payments/'.$path;
            $proof->payment_id = $payment->id;
            $proof->save();  
            
        }

        return response()->json([
            'message' => 'invoice paid successfully'
        ],200);
    }

}
