<?php

namespace App\Http\Controllers;

use PDF;
use App\User;
use App\Client;
use App\Invoice;
use App\Payment;
use Illuminate\Http\Request;
use App\PaymentGatewayConfig;
use App\Exports\PaymentExport;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Session;
use App\Http\Requests\StorePaymentConfig;
use DB;

class ClientLiabilitiesController extends Controller
{
    public function createClientLiabilitiesNew ($client_reference_id , $client_type) {
    //  var_dump('gets here');
    //  dd();
        session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $userId = $_SESSION['userId'];

        $client_owners = DB::select("SELECT * FROM clients WHERE client_reference_id = '".$client_reference_id."'");
        
            
        $client_owners_merge = DB::table('clients')
            ->where('client_reference_id', $client_reference_id)
            ->where('client_type','Spouse')
            ->get()
            ->map(function($client) {
                $data['id'] = $client->id;
                $data['first_name'] = $client->first_name;
                $data['last_name'] = $client->last_name;
                $data['type'] = $client->client_type;
                $data['is_type'] = 'Client';
                return $data;
            });
        $client_dependents = DB::table('dependants')
            ->where('client_reference_id', $client_reference_id)
            ->get()
            ->map(function($dependant) {
                $data['id'] = $dependant->id;
                $data['first_name'] = $dependant->first_name;
                $data['last_name'] = $dependant->last_name;
                $data['type'] = $dependant->dependant_type;
                $data['is_type'] = 'Dependant';
                return $data;
        });
        $client_beneficiary = collect($client_owners_merge)->merge(collect($client_dependents)); 

    	return view('fna.createClientLiabilitiesNew',[ 'client_reference_id' => $client_reference_id, 'client_type' => $client_type, 'client_owners' => $client_owners, 'client_beneficiary' => $client_beneficiary]); 
    }
    
    public function storeClientLiablilities(Request $request)
    {
  
        $request->validate([
            
            'liability_type' => 'required',
            'liability_name' => 'required',
            'policy_number' => 'required',
            'outstanding_balance' => 'required|numeric',
            'under_advice' => 'required',
            'type_of_business' => 'required',
            'original_balance' => 'required|numeric',
            'loan_application_amount' => 'required|numeric',
            'limit' => 'required|numeric',
            'principal_repaid' => 'required|numeric',
            'last_updated_by' => 'required',
            'interest_rate_type' => 'required',
            'interest_rate_pa' => 'required|numeric',
            'loan_term' => 'required|numeric',
            'loan_term_value' => 'required|numeric',
            'repayment_amount' => 'required|numeric',
            'repayment_frequency' => 'required',
            'select_asset_type' => 'required',
            
            ]);
        
        
        // var_dump($_POST);
        // dd();
          session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $userId = $_SESSION['userId'];
         
        $liabilitiesId = DB::table('client_liabilities_new')->insertGetId(
		[
			'advisor_id' => $_POST['advisor_id'],
			'capture_advisor_id' => $_POST['capture_advisor_id'],
			'client_reference_id' => $_POST['client_reference_id'],
			'liability_type' => $_POST['liability_type'],
			'liability_name' => $_POST['liability_name'],
			'policy_number' => $_POST['policy_number'],
			'outstanding_balance' => $_POST['outstanding_balance'],
			'under_advice' => $_POST['under_advice'],
			'type_of_business' => $_POST['type_of_business'],
			'original_balance' => $_POST['original_balance'],
			'loan_application_amount' => $_POST['loan_application_amount'],
			'thelimit' => $_POST['limit'],
			'principal_repaid' => $_POST['principal_repaid'],
			'last_updated_by' => $_POST['last_updated_by'],
			'interest_rate_type' => $_POST['interest_rate_type'],
			'interest_rate_pa' => $_POST['interest_rate_pa'],
			'loan_term' => $_POST['loan_term'],
			'loan_term_value' => $_POST['loan_term_value'],
			'repayment_amount' => $_POST['repayment_amount'],
			'repayment_frequency' => $_POST['repayment_frequency'],
			'select_asset_type' => $_POST['select_asset_type']
		]);
        
        
        if(isset($_POST['asset_owners_id'])){
            $owner_count = count($_POST['asset_owners_id']); 
            if($owner_count >0) {
                    for($i = 0; $i < $owner_count; $i++)
                    {
                        $saveclientAssetsBeneficiary = DB::table('client_liabilities_ownership')->insert([
                        	'owner_id' => $_POST['asset_owners_id'][$i],
                        	'type' => $_POST['owners_item_type'][$i],
                        	'client_reference_id' => $_POST['owners_client_reference_id'][$i],
                        	'liabilities_id' => $liabilitiesId,
                        	'percentage' => $_POST['asset_allocation_owners'][$i]
                        ]);
                    }
             }
        }
        $client_reference_id= $_POST['client_reference_id'];
        $client_owners = DB::select("SELECT * FROM `clients` where client_reference_id = '". $client_reference_id ."'");
          
        $result = DB::select("SELECT * FROM `client_assets` where client_reference_id = '".$client_reference_id."'");
        $result2 = DB::select("SELECT * FROM `client_liabilities_new` where client_reference_id = '".$client_reference_id."'");
        //$result2 = DB::select("SELECT client_assets_liabilities.id, client_assets_liabilities.item_type, client_assets_liabilities.item_name, client_assets_liabilities.item_value, client_assets_liabilities.date_purchased, client_assets_liabilities.owners_id , concat(clients.first_name, ' ',clients.last_name) as owners_id FROM `client_assets_liabilities` INNER JOIN clients On owners_id = clients.id where client_assets_liabilities.asset_liability_type = '2' and client_assets_liabilities.client_reference_id = '".$client_reference_id."'");
        
        $clientType = DB::select("SELECT client_type from clients where client_reference_id = '". $client_reference_id ."'");
        $client_type= ($clientType[0]->client_type);
        
        
        $client_owners = DB::select("SELECT * FROM `clients` where client_reference_id = '". $client_reference_id ."'");
        // return view('fna.updateDeleteAssetsLiabilities',[ 'result' => $result,'result2' => $result2, 'client_reference_id' => $client_reference_id, 'client_type' => $client_type , 'getAccessName'=>$getAccessName,'clientLiabilities'=>$client_owners,'client_owners'=>$client_owners])->with($result);
        return view('fna.updateDeleteAssetsLiabilities',[ 'result' => $result,'result2' => $result2,'client_type' => $client_type, 'client_reference_id' => $client_reference_id,'client_owners'=>$client_owners]);
    	return redirect()->route('clientLiabilitiesList'); 
    }
    
    
public function editLiabilityNew($clientReff, $id){
    
    // var_dump('gets here');
    // dd();
    $liability = DB::select("SELECT * FROM client_liabilities_new  WHERE id = '".$id."' AND client_reference_id = '".$clientReff."'");
    $liabilityOwners = DB::select("SELECT id, first_name, last_name FROM `clients` where client_reference_id=  '".$clientReff."'");
    $owners = DB::select("SELECT * FROM client_liabilities_ownership");
    $query_owner = DB::select("SELECT * FROM client_liabilities_ownership WHERE client_reference_id = '".$clientReff."' AND liabilities_id = '".$id."'");
        // print_r($query_owner);
       
        
        $arrOwners = array();
      
        for($i=0; $i<count($query_owner); $i++) {
            $client_owner = DB::table('clients')
                            ->where('id', $query_owner[$i]->owner_id)
                            ->get()
                            ->map(function($client) {
                                $data['id'] =  $client->id;
                                $data['first_name'] = $client->first_name;
                                $data['last_name'] = $client->last_name;
                                $data['type'] = $client->client_type;
                                $data['percentage'] = $client->client_type;
                                return $data;
                            });
                            
            array_push($arrOwners,$client_owner);
        }
        
       
    
     $client_owners = DB::table('clients')
            ->where('client_reference_id', $clientReff)
            ->get()
            ->map(function($client) {
                $data['id'] = $client->id;
                $data['first_name'] = $client->first_name;
                $data['last_name'] = $client->last_name;
                $data['type'] = $client->client_type;
                $data['is_type'] = 'Client';
                return $data;
            });
            
    $liability_owners = DB::select("SELECT `client_liabilities_ownership`.id, owner_id, liabilities_id, percentage, first_name, last_name , 
        client_type , type FROM `client_liabilities_ownership` 
        left join clients on clients.id = owner_id WHERE client_liabilities_ownership.`client_reference_id`  = '".$clientReff."' AND liabilities_id = '".$id."'");
    $clientOwners = DB::select("SELECT * FROM clients WHERE client_reference_id = '".$clientReff."'"); 
    
    
    $client_liabilities_owners = DB::table('client_liabilities_ownership')->where('liabilities_id', $id)->get();
   //dd($client_owners);
    return view('fna.editLiablilityNew',['liability'=>$liability[0],'asset_owners' => $liability_owners, 'client_reference_id'=>$clientReff, 'client_owners'=>$client_owners, 'liability_owners' => $arrOwners]);
}


public function update_Liability(Request $request){
    
    // var_dump($_POST);
    // die();
     $request->validate([
            
            'liability_type' => 'required',
            'liability_name' => 'required',
            'policy_number' => 'required',
            'outstanding_balance' => 'required|numeric',
            'under_advice' => 'required',
            'type_of_business' => 'required',
            'original_balance' => 'required|numeric',
            'loan_application_amount' => 'required|numeric',
            'thelimit' => 'required|numeric',
            'principal_repaid' => 'required|numeric',
            'last_updated_by' => 'required',
            'interest_rate_type' => 'required',
            'interest_rate_pa' => 'required|numeric',
            'loan_term' => 'required|numeric',
            'loan_term_value' => 'required|numeric',
            'repayment_amount' => 'required|numeric',
            'repayment_frequency' => 'required',
            'select_asset_type' => 'required',
            
            ]);
    
         session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $userId = $_SESSION['userId'];
        $user_id = 1;
        $id = $_POST["liability_id"]; 
        $client_reference_id =$_POST["client_reference_id"]; 
        $query = DB::select("UPDATE client_liabilities_new SET 
        	advisor_id='".$_POST["advisor_id"]."', 
        	capture_advisor_id='".$_POST['capture_advisor_id']."', 
        	client_reference_id='".$_POST['client_reference_id']."', 
        	liability_type='".$_POST['liability_type']."', 
        	liability_name='".$_POST['liability_name']."', 
        	policy_number='".$_POST['policy_number']."', 
        	outstanding_balance='".$_POST['outstanding_balance']."', 
        	under_advice='".$_POST['under_advice']."', 
        	type_of_business='".$_POST['type_of_business']."', 
        	original_balance='".$_POST['original_balance']."', 
        	loan_application_amount='".$_POST['loan_application_amount']."', 
        	thelimit='".$_POST['thelimit']."', principal_repaid='".$_POST['principal_repaid']."', 
        	last_updated_by='".$_POST['last_updated_by']."', 
        	interest_rate_type='".$_POST['interest_rate_type']."', 
        	interest_rate_pa='".$_POST['interest_rate_pa']."', 
        	loan_term='".$_POST['loan_term']."', 
        	loan_term_value='".$_POST['loan_term_value']."', 
        	repayment_amount='".$_POST['repayment_amount']."', 
        	repayment_frequency='".$_POST['repayment_frequency']."', 
        	select_asset_type='".$_POST['select_asset_type']."' 
        	where client_reference_id ='$client_reference_id' AND id = '$id'"); 
  
        
        if(isset($_POST["asset_owners_id"])){
   
        $beneficiary_count = count($_POST['asset_owners_id']);
         if($beneficiary_count >0) {
         //delete old oweners infor
             $qryDelete = DB::select("DELETE FROM client_liabilities_ownership WHERE client_reference_id = '".$_POST['client_reference_id']."' "); 
        //add/update new owners
        for($i = 0; $i < $beneficiary_count; $i++)
        {
            $saveclientLiabilityOwnersy = DB::table('client_liabilities_ownership')->insert([
                        	'owner_id' => $_POST['asset_owners_id'][$i],
                        	'type' => $_POST['owners_item_type'][$i],
                        	'client_reference_id' => $_POST['owners_client_reference_id'][$i],
                        	'liabilities_id' => $_POST['liability_id'],
                        	'percentage' => $_POST['asset_allocation_owners'][$i]
                        ]);
        }
        }
        }
        
        
        //dd('done');
         $client_reference_id = $_POST["client_reference_id"];
        return redirect()->route('clients.liablilities.edit',['client_reference_id' => $client_reference_id,'id' => $id ]);
        
}

 public function delete_Liability($client_reference_id, $id) {
        session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $userId = $_SESSION['userId'];
        $query1 = DB::select("DELETE FROM client_liabilities_ownership  WHERE client_reference_id = '".$client_reference_id."' AND liabilities_id = '".$id."'");
        $query = DB::select("DELETE FROM client_liabilities_new where client_reference_id  = '".$client_reference_id."' AND id = '".$id."'");      
   
    	return redirect()->route('updateDeleteAssetsLiabilities',['client_reference_id' => $client_reference_id , 'client_type' => 'Main Client' ]);
    }
    

}
