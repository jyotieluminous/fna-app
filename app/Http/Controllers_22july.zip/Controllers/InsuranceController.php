<?php

namespace App\Http\Controllers;

use PDF;
use App\User;
use App\Client;
use App\Invoice;
use App\Payment;
use Illuminate\Http\Request; 
use App\PaymentGatewayConfig;
use App\Exports\PaymentExport;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Session;
use App\Http\Requests\StorePaymentConfig;
use DB;
use DataTables;

class InsuranceController extends Controller
{
    private $login;
    private $userId;
    private $userType;
    private $roleId;
    public function __construct()
    {
        //$this->middleware('auth');
    }
    
    public function index()  
    {
        $clients = DB::table('clients')
        ->where('client_type','Main Client')
        ->get()
        ->map(function($client) {
            $clientData['id'] = $client->id;
            $clientData['first_name'] = $client->first_name;
            $clientData['last_name'] = $client->last_name;
            $clientData['client_reference_id'] = $client->client_reference_id;
            return $clientData;
        });
        $query = DB::select("SELECT * FROM client_insurances"); 
        return view('insurance.insuranceList',['client_insurance'=>$query,'clients'=>$clients]);
    }
    
    public function indexList($client_reference_id)  
    {
        $query = DB::select("SELECT * FROM client_insurances WHERE client_reference_id = '".$client_reference_id."'"); 
        return view('insurance.insuranceListView',['client_insurance'=>$query,'client_reference_id'=>$client_reference_id]);
    }
    
    public function createInsurance($client_reference_id){
        
        $clientReff = $client_reference_id; 
        $client_owners = DB::table('clients')->where('client_reference_id', $clientReff)->get()->map(function($client) {
            $data['id'] = $client->id.'_Client';
            $data['first_name'] = $client->first_name;
            $data['last_name'] = $client->last_name;
            $data['type'] = $client->client_type;
            return $data;
        });
                       
        $client_dependents = DB::table('dependants')->where('client_reference_id', $clientReff)->get()->map(function($dependant) {
            $data['id'] = $dependant->id.'_Dependant';
            $data['first_name'] = $dependant->first_name;
            $data['last_name'] = $dependant->last_name;
            $data['type'] = $dependant->dependant_type;
            return $data;
        });
        $owners = collect($client_owners)->merge(collect($client_dependents));
        return view('insurance.createInsurance',['client_reference_id'=>$clientReff,'client_owners'=> $owners]);
    }
    
    public function saveInsurance(Request $request,$client_reference_id){
        
        session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $userId = $_SESSION['userId'];
        $insuranceId = DB::table('client_insurances')->insertGetId(
        [
            'advisor_id' => $_POST['advisor_id'],
            'capture_advisor_id' => $_POST['capture_advisor_id'],
            'client_reference_id' => $_POST['client_reference_id'],
            'life_cover_description' => $_POST['life_cover_description'],
            'life_cover_policy_ref' => $_POST['life_cover_policy_ref'],
            'life_cover_owner' => $_POST['life_cover_owner'],
            'life_cover_assured' => $_POST['life_cover_assured'],
            'life_cover_cash_value' => $_POST['life_cover_cash_value'],
            'life_cover_death' => $_POST['life_cover_death'],
            'life_cover_disability' => $_POST['life_cover_disability'],
            'life_cover_dread_disease' => $_POST['life_cover_dread_disease'],
            'life_cover_impairment' => $_POST['life_cover_impairment'],
            'sick_description' => $_POST['sick_description'],
            'sick_monthly_amount' => $_POST['sick_monthly_amount'],
            'sick_frequency' => $_POST['sick_frequency'],
            'sick_waiting_period' => $_POST['sick_waiting_period'],
            'sick_term' => $_POST['sick_term'],
            'sick_claim_escalation' => $_POST['sick_claim_escalation'],
            'sick_esc' => $_POST['sick_esc'],
            'income_protect_description' => $_POST['income_protect_description'],
            'income_protect_monthly_amount' => $_POST['income_protect_monthly_amount'],
            'income_protect_frequency' => $_POST['income_protect_frequency'],
            'income_protect_waiting_period' => $_POST['income_protect_waiting_period'],
            'income_protect_term' => $_POST['income_protect_term'],
            'income_protect_claim_escalation' => $_POST['income_protect_claim_escalation'],
            'income_protect_esc' => $_POST['income_protect_esc'],
            'death_term_related_to' => $_POST['death_term_related_to'],
            'death_description' => $_POST['death_description'],
            'death_date_of_birth' => $_POST['death_date_of_birth'],
            'death_waiting_period' => $_POST['death_waiting_period'],
            'death_term' => $_POST['death_term'],
            'death_claim_escalation' => $_POST['death_claim_escalation'],
            'death_esc' => $_POST['death_esc'],
            'insurance_allocation_for_death' => $_POST['insurance_allocation_for_death'],
            'insurance_allocation_for_disability' => $_POST['insurance_allocation_for_disability'],
            'insurance_allocation_for_dread_disease' => $_POST['insurance_allocation_for_dread_disease'],
            'insurance_allocation_for_impairment' => $_POST['insurance_allocation_for_impairment'],
            'insurance_allocation_for_income_benefits' => $_POST['insurance_allocation_for_income_benefit']
            
        ]);
        
        if(isset($_POST['owner_id'])){
            $owner_count = count($_POST['owner_id']); 
            if($owner_count >0) {
                    for($i = 0; $i < $owner_count; $i++)
                    {
                        $owner_id_type = explode('_',$_POST['owner_id'][$i]);
                        $saveclientAssetsBeneficiary = DB::table('client_insurances_beneficiary')->insert([
                            'owner_id' =>  $owner_id_type[0],
                            'type' =>  $owner_id_type[1],
                            'client_reference_id' => $_POST['client_reference_id'],
                            'insurance_id' => $insuranceId,
                            'percentage' => $_POST['percentage'][$i]
                        ]);                
                    }
             }
        }
        return \Redirect::route('insuranceList', [$client_reference_id]);
        
    }
    
    public function fetchUpdateInsuranceList(Request $request,$client_reference_id,$id){
            session_start();
            if(empty($_SESSION['login']))
            {
                header("location: https://fna.phpapplord.co.za/public/");
                exit;
            }
            $userId = $_SESSION['userId'];
            $query = DB::select("SELECT * FROM client_insurances WHERE client_reference_id = '".$client_reference_id."' AND id='".$id."' ");        
            $InsurancesBeneficiary = DB::select("SELECT * FROM client_insurances_beneficiary WHERE client_reference_id = '".$client_reference_id."' AND insurance_id='".$id."'");
            
            $clientReff = $client_reference_id; 
            $client_owners = DB::table('clients')->where('client_reference_id', $clientReff)->get()->map(function($client) {
                $data['id'] = $client->id;
                $data['first_name'] = $client->first_name;
                $data['last_name'] = $client->last_name;
                $data['type'] = $client->client_type;
                $data['reletion_type'] = 'Client';
                return $data;
            });
            $client_dependents = DB::table('dependants')->where('client_reference_id', $clientReff)->get()->map(function($dependant) {
                $data['id'] = $dependant->id;
                $data['first_name'] = $dependant->first_name;
                $data['last_name'] = $dependant->last_name;
                $data['type'] = $dependant->dependant_type;
                $data['reletion_type'] = 'Dependant';
                return $data;
            });
            $owners = collect($client_owners)->merge(collect($client_dependents));
            return view('insurance.InsuranceUpdateView',[
                'client_insurance'=>$query,
                'client_owners'=>$owners, 
                'client_reference_id'=>$client_reference_id,
                'InsurancesBeneficiary'=>$InsurancesBeneficiary
                ]);
    }
    
    public function UpdateInsuranceList(Request $request,$client_reference_id,$id){
        session_start();
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        }
        $userId = $_SESSION['userId'];
        $user_id = 1;
        $query = DB::select('UPDATE client_insurances SET 
            advisor_id="'.$_POST["advisor_id"].'",
            capture_advisor_id="'.$_POST["capture_advisor_id"].'",
            client_reference_id="'.$client_reference_id.'",
            life_cover_description="'.$_POST["life_cover_description"].'",
            life_cover_policy_ref="'.$_POST["life_cover_policy_ref"].'",
            life_cover_owner="'.$_POST["life_cover_owner"].'", 
            life_cover_assured="'.$_POST["life_cover_assured"].'", 
            life_cover_cash_value="'.$_POST["life_cover_cash_value"].'",
            life_cover_death="'.$_POST["life_cover_death"].'", 
            life_cover_disability="'.$_POST["life_cover_disability"].'", 
            life_cover_dread_disease="'.$_POST["life_cover_dread_disease"].'", 
            life_cover_impairment="'.$_POST["life_cover_impairment"].'", 
            sick_description="'.$_POST["sick_description"].'" ,
            sick_monthly_amount="'.$_POST["sick_monthly_amount"].'" ,
            sick_frequency="'.$_POST["sick_frequency"].'" ,
            sick_waiting_period="'.$_POST["sick_waiting_period"].'", 
            sick_term="'.$_POST["sick_term"].'" ,
            sick_claim_escalation="'.$_POST["sick_claim_escalation"].'" ,
            sick_esc="'.$_POST["sick_esc"].'", 
            income_protect_description="'.$_POST["income_protect_description"].'" ,
            income_protect_monthly_amount="'.$_POST["income_protect_monthly_amount"].'" ,
            income_protect_frequency="'.$_POST["income_protect_frequency"].'" , 
            income_protect_waiting_period="'.$_POST["income_protect_waiting_period"].'" , 
            income_protect_term="'.$_POST["income_protect_term"].'" ,               
            income_protect_claim_escalation="'.$_POST["income_protect_claim_escalation"].'" , 
            income_protect_esc="'.$_POST["income_protect_esc"].'" , 
            death_term_related_to="'.$_POST["death_term_related_to"].'" ,
            death_description="'.$_POST["death_description"].'" ,
            death_date_of_birth="'.$_POST["death_date_of_birth"].'" ,
            death_waiting_period="'.$_POST["death_waiting_period"].'" ,
            death_term="'.$_POST["death_term"].'" ,
            death_claim_escalation="'.$_POST["death_claim_escalation"].'" ,
            death_esc="'.$_POST["death_esc"].'" , 
            insurance_allocation_for_death="'.$_POST["insurance_allocation_for_death"].'" ,
            insurance_allocation_for_disability="'.$_POST["insurance_allocation_for_disability"].'" ,
            insurance_allocation_for_dread_disease="'.$_POST["insurance_allocation_for_dread_disease"].'" , 
            insurance_allocation_for_impairment="'.$_POST["insurance_allocation_for_impairment"].'" , 
            insurance_allocation_for_income_benefits="'.$_POST["insurance_allocation_for_income_benefits"].'" 
             
            WHERE client_reference_id="'.$client_reference_id.'" AND id="'.$id.'" ');
            
            DB::select("DELETE FROM `client_insurances_beneficiary` where client_reference_id = '$client_reference_id' AND  insurance_id = '$id'");              
            if(isset($_POST['owner_id'])){
            $owner_count = count($_POST['owner_id']); 
            
            if($owner_count >0) {
                    for($i = 0; $i < $owner_count; $i++)
                    {
                        $owner_id_type = explode('_',$_POST['owner_id'][$i]);
                        $saveclientAssetsBeneficiary = DB::table('client_insurances_beneficiary')->insert([
                            'owner_id' => $owner_id_type[0],
                            'type' => $owner_id_type[1],
                            'client_reference_id' => $client_reference_id,
                            'insurance_id' => $id,
                            'percentage' => $_POST['percentage'][$i]
                        ]);                
                    }
             }
        }
        
        return \Redirect::route('insuranceList', [$client_reference_id]);        
    }
    
    public function deleteInsuranceList($client_reference_id,$id){
        DB::select("DELETE FROM `client_insurances` where client_reference_id = '$client_reference_id' AND  id = '$id'");
        DB::select("DELETE FROM `client_insurances_beneficiary` where client_reference_id = '$client_reference_id' AND  insurance_id = '$id'");
        return \Redirect::route('insuranceList', [$client_reference_id]);   
    }
}