<?php

namespace App\Http\Controllers;

use PDF;
use App\User;
use App\Client;
use App\Invoice;
use App\Payment;
use Illuminate\Http\Request;
use App\PaymentGatewayConfig;
use App\Exports\PaymentExport;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Session;
use App\Http\Requests\StorePaymentConfig;
use DB;
use DataTables;

class AuditTrailController extends Controller
{
    private $login;
    private $userId;
    private $userType;
    private $roleId;
    public function __construct()
    {
        //$this->middleware('auth');
    }
    
    
    public function index(Request $request) {
        session_start(); 
        if(empty($_SESSION['login']))
        {
            header("location: https://fna.phpapplord.co.za/public/");
            exit;
        } 
        $userId = $_SESSION['userId'];
        
        $liabilitiesModule = 'Liabilities';
        $personalInfoModule = 'Personal Information';
        
        // $liabilitiesModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$liabilitiesModule'");
         $personalInfoModuleModuleId = DB::select("SELECT * FROM `modules` where name = '$personalInfoModule'");
        
        // Get Role Id Of User
        $getroleId = DB::select("SELECT * FROM `permissions` where userId = '".$userId."'");
        //var_dump($getroleId); die();
        if(!isset($getroleId[0]->groupId))
        {
            header("location: https://fna.phpapplord.co.za/public/noAccess");
            exit;
        }
        else
        {
             /*
                Get Access Id to get Read/write access or Access Name
            */
            $getAclAccessId = DB::select("SELECT * FROM `acl` where roleId = '".$getroleId[0]->groupId."' and moduleId = '".$personalInfoModuleModuleId[0]->id."'");
            if(!isset($getAclAccessId[0]->accessId))
            {
                header("location: https://fna.phpapplord.co.za/public/noAccess");
                exit;
            }
            $getAccessName = DB::select("SELECT * FROM `access` where id = '".@$getAclAccessId[0]->accessId."'");
            if(!isset($getAccessName[0]->name))
            {
                header("location: https://fna.phpapplord.co.za/public/noAccess");
                exit;
            }
            else
            {
                if($getAccessName[0]->name == "no-access")
                {
                    header("location: https://fna.phpapplord.co.za/public/noAccess");
                    exit;
                }
            }
        }           
        return view('auditTrail.listAuditTrail',['getAccessName'=>$getAccessName]);
    }
    
    public function listAuditAjax(Request $request) {
        if ($request->ajax()) {
            $clients = "SELECT 
                        audit.id, 
                        concat(users.name , ' ' , users.surname) as user, 
                        module, 
                        role, 
                        action as action_by, 
                        date FROM `audit` Left JOIN users on users.id = audit.user 
                        ";
            if(!empty($request->from_date) and !empty($request->module_name)) {
                    $clients .= " WHERE 
                    (date BETWEEN '". $request->from_date ."' AND '". $request->to_date ."')
                    AND module LIKE '%" . $request->module_name . "%'
                    ";  
            } elseif (!empty($request->module_name)) {
                $clients .= "WHERE module LIKE '%" . $request->module_name . "%'";
            } elseif (!empty($request->from_date)) {
                $clients .= "WHERE (date BETWEEN '". $request->from_date ."' AND '". $request->to_date ."')";  
            }
            $clients  = DB::select($clients);

            return Datatables::of($clients)
                    ->addIndexColumn()
                    ->make(true);
        }
        return view('auditTrail.listAuditTrail');
    }
    
    public function store(Request $request)
    {
        die('store');
     
    }	

    public function exportCsv(Request $request) {
    $fileName = 'Audittrail.csv';
    $clients = DB::select("SELECT audit.id, concat(users.name , ' ' , users.surname) as user, module, role, action as action_by, date FROM `audit` Left JOIN users on users.id = audit.user");  

        $headers = array(
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=$fileName",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0"
        );

        $columns = array('Id', 'Date', 'Changes', 'User', 'Details', 'Role');

        $callback = function() use($clients, $columns) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);

            foreach ($clients as $client) {
                $row['Id']  = $client->id;
                $row['Date']    = $client->date;
                $row['Changes']    = $client->module;
                $row['User']  = $client->user;
                $row['Details']  = $client->action_by;
                $row['Role']  = $client->role;
                fputcsv($file, array($row['Id'], $row['Date'], $row['Changes'], $row['User'], $row['Details'], $row['Role']));
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
    
    public function exportCsvFilter(Request $request) {
        // dd($_POST);
            $clients = "SELECT 
                        audit.id, 
                        concat(users.name , ' ' , users.surname) as user, 
                        module, 
                        role, 
                        action as action_by, 
                        date FROM `audit` Left JOIN users on users.id = audit.user 
                        ";        
            if(!empty($request->from_date) and !empty($request->module_name) and !empty($request->search_keyword)) {
                    $clients .= " WHERE 
                    (date BETWEEN '". $request->from_date ."' AND '". $request->to_date ."')
                    AND module LIKE '%" . $request->module_name . "%'
                    AND action LIKE '%" . $request->search_keyword . "%'
                    ";  
            } elseif(!empty($request->from_date) and !empty($request->module_name)) {
                    $clients .= " WHERE 
                    (date BETWEEN '". $request->from_date ."' AND '". $request->to_date ."')
                    AND module LIKE '%" . $request->module_name . "%'
                    ";  
            } elseif (!empty($request->module_name)) {
                $clients .= "WHERE module LIKE '%" . $request->module_name . "%'";
            } elseif (!empty($request->from_date)) {
                $clients .= "WHERE (date BETWEEN '". $request->from_date ."' AND '". $request->to_date ."')";  
            } elseif (!empty($request->search_keyword)) {
                $clients .= "WHERE module LIKE '%" . $request->search_keyword . "%' OR  action LIKE '%" . $request->search_keyword . "%' ";  
            }

        $fileName = 'Audittrailfilter.csv';
        $clients  = DB::select($clients);
        $headers = array(
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=$fileName",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0"
        );

        $columns = array('Id', 'Date', 'Changes', 'User', 'Details', 'Role');

        $callback = function() use($clients, $columns) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);

            foreach ($clients as $client) {
                $row['Id']  = $client->id;
                $row['Date']    = $client->date;
                $row['Changes']    = $client->module;
                $row['User']  = $client->user;
                $row['Details']  = $client->action_by;
                $row['Role']  = $client->role;
                fputcsv($file, array($row['Id'], $row['Date'], $row['Changes'], $row['User'], $row['Details'], $row['Role']));
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}