<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

class BankStatementController extends Controller
{
    public function bankStatementNotice($client_reference, $client_type) {

        return view('bank_statement_notice', ['client_reference_id' => $client_reference, 'client_type' => $client_type]);
    }
    
    public function storeBankStatement(Request $request)
    {

        session_start();

        if (empty($_SESSION['login'])) {
            header("location: http://fna2.phpapplord.co.za/public/");
            exit;
        }

        $request->validate([
            'file'  => 'required|mimes:pdf|max:10000'
        ]);

        $client_reference_id = $request->client_reference_id;

        if($_SESSION['userType'] == 'Client')
        {
             $userId = $_SESSION['userId'];
 
        }else {
             $userId = $request->client;
        }
        

        if ($request->hasFile('file')) {

            $file = $request->file('file');

            $filename = time() . '_' . $file->getClientOriginalName();

            $extension = $file->getClientOriginalExtension();

            $location = storage_path() . '/public/documents/';

            $file->move($location, $filename);

            $filepath = url('files/' . $filename);

  
            $filepath = $location . $filename;
     
            $file = fopen($filepath, "r");
           
            $this->BankstatementsAuth($filepath, $file, $client_reference_id, $userId);
            
            if($request->session()->get('bank_statement_status') == 'Failed')
            {
                return redirect()->back()->withErrors('please provide a valid for pdf bank statement');

            }

            if($request->session()->get('bank_statement_status') == 'Currently Unavailable')
            {
                return redirect()->back()->withErrors('bank statement failed please try again later!');
            }
            
            
                    $client = DB::table('clients')
                            ->where('user_id', $userId)
                            ->first();
          
            $client_latest_expense_captured = DB::table('budget')
                                                ->where('client_reference_id', $client_reference_id)
                                                ->where('client_type', $client->client_type)
                                                ->where('income_expenses_type', 2)
                                                ->orderBy('id', 'desc')
                                                ->first();
            

            DB::table('bank_transaction')->insert([
                'advisor_id' => $userId,
                'advisor_capture_id' => '',
                'client_id' => $userId,
                'client_reference_id' => $client_reference_id,
                'date' => date("y-m-d"),
                'capture_date' => date("y-m-d"),
                'file_name' => $filename,
                'latest_month_captured' => explode('-', $client_latest_expense_captured->capture_date)[1]
            ]);
            
            return redirect()->back()->withSuccess('Bank statement statement successfully uploaded');


        }
    }


    function BankstatementsAuth($filePath, $file, $client_reference_id, $userId)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://sandbox-api.tryfetch.me/bank-connect/graphql',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => '{"query":"query\\n{ \\n  auth(key: \\"7Fqpu8Pd3G4h10eL0oGakNMbG5Mu1gTr\\"){\\n    token, expires, expires_in, token_type\\n  }\\n}","variables":{}}',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        $token = json_decode($response);
        
        if(!$token)
        {
            Session::put("bank_statement_status", 'Currently Unavailable');
            return redirect()->back()->withErrors('please provide a valid for pdf bank statement');
        }

        $getToken = $token->data->auth->token;


        $this->UploadBankstatements($getToken, $filePath, $file, $client_reference_id, $userId);
    }


    function UploadBankstatements($token, $filepath, $file, $client_reference_id, $userId)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://sandbox-api.tryfetch.me/bank-statement/graphql',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('0' => new \CURLFILE($filepath, 'pdf', 'file'), 'operations' => '{ "query": "query ($file: Upload!, $password: String) { parseBankStatement(file: $file, password: $password) {bank_alias, bank_name, begin_date, end_date, debit_total, credit_total, statement_type, statement_number, opening_balance, closing_balance, account {id, available_balance, current_balance, credit_line,account_holder, account_number, title, credit_line}, salary{id, amount, full_title}, transactions {id, account_id, full_title, title, amount, service_fee, transaction_date, running_balance, order, category {id, title}, currency}}}", "variables": { "file": null, "password": ""} }', 'map' => '{ "0": ["variables.file"]}'),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: multipart/form-data',
                'Authorization: Bearer ' . $token . ''
            ),
        ));

        $response = curl_exec($curl);
        
        curl_close($curl);

        $getProductSectorSet = json_decode($response);

        // dd($getProductSectorSet->data->parseBankStatement->transactions[0]);

        if(!$getProductSectorSet->data->parseBankStatement)
        {
            Session::put('bank_statement_status', 'Failed');
            return redirect()->back()->withErrors('please provide a valid for pdf bank statement');
        } 
        

        DB::table('integrationData')->insert([
            'ClientReference' => $client_reference_id,
            'jsonobject' => json_encode($response),
            'Type' => 'Bank Statement API'
            ]);
            


       $transactions = $getProductSectorSet->data->parseBankStatement->transactions;
              

       //insert into income and expenses. 
       foreach ($transactions as $transaction) {

        $categroy_name = $transaction->category->title;

        if($transaction->amount > 0)
        {
            $income_expenses_type = 1;

        }else {

            $income_expenses_type = 2;
        }
        
        $client = DB::table('clients')->where('user_id', $userId)->first();

            if(DB::table('budget')
                    ->where('item_type', $transaction->full_title)
                    ->where('item_name', $categroy_name)
                    ->where('income_expenses_type', $income_expenses_type)
                    ->whereDate('capture_date', $transaction->transaction_date)
                    ->where('client_id', $client->id)
                    ->count() == 0) {   
                        
                        if($transaction->amount > 0)
                        {

                            $income_name_count = DB::table('income_expense_type')->where('income_expense_name', $categroy_name)->where('income_expense_type', 1)->count();
                            if($income_name_count > 0)
                            {
                                $item_name = DB::table('income_expense_type')
                                ->where('income_expense_name', $categroy_name)
                                ->where('income_expense_type', 1)
                                ->first();

                            }else {

                                $item_name_id = DB::table('income_expense_type')
                                                ->insertGetId([
                                                    'income_expense_name' => $categroy_name,
                                                    'income_expense_type' => 1
                                                ]);
                            }
               

                        }else {

                            $income_name_count = DB::table('income_expense_type')->where('income_expense_name', $categroy_name)->where('income_expense_type', 2)->count();
                            if($income_name_count > 0)
                            {
                                $item_name = DB::table('income_expense_type')
                                ->where('income_expense_name', $categroy_name)
                                ->where('income_expense_type', 2)
                                ->first();

                            }else {

                                $item_name_id = DB::table('income_expense_type')
                                                ->insertGetId([
                                                    'income_expense_name' => $categroy_name,
                                                    'income_expense_type' => 2
                                                ]);
                            }

                        }


                        $budget_id = DB::table('budget')->insertGetId([
                            'client_reference_id' => $client->client_reference_id,
                            'advisor_id' => $client->advisor_id,
                            'advisor_capture_id' => $client->advisor_id,
                            'client_id' => $client->id,
                            'client_type' => $client->client_type,
                            'income_expenses_type' => $income_expenses_type,
                            'item_type_id' => $income_name_count > 0 ? $item_name->id : $item_name_id,
                            'item_type' => $transaction->full_title,
                            'item_id' => $income_name_count > 0 ? $item_name->id : $item_name_id,
                            'item_name' => $income_name_count > 0 ? $item_name->income_expense_name : DB::table('income_expense_type')->where('id', $item_name_id)->first()->income_expense_name,
                            'item_value' => abs($transaction->amount),
                            'capture_date' => $transaction->transaction_date
                        ]);
            
                            DB::table('yearly_budget')->insert([
                                'client_reference_id' => $client->client_reference_id,
                                'advisor_id' => $client->advisor_id,
                                'advisor_capture_id' => $userId,
                                'budget_id' => $budget_id,
                                'client_id' => $client->id,
                                'client_type' => $client->client_type,
                                'income_expenses_type' => $income_expenses_type,
                                'item_type_id' => $income_name_count > 0 ? $item_name->id : $item_name_id,
                                'item_type' => $transaction->full_title,
                                'item_id' => $income_name_count > 0 ? $item_name->id : $item_name_id,
                                'item_name' => $income_name_count > 0 ? $item_name->income_expense_name : DB::table('income_expense_type')->where('id', $item_name_id)->first()->income_expense_name,
                                'item_value' => abs($transaction->amount),
                                'month' => explode('-', $transaction->transaction_date)[1],
                                'year' => explode('-', $transaction->transaction_date)[0],
                                'capture_date' => $transaction->transaction_date
                            ]);
                        
                
            }
            
            Session::put('bank_statement_status', 'Success');
        
    }
}
}
