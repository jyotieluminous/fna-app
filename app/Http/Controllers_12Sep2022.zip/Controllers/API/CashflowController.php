<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\DB;

class CashflowController extends Controller
{
    

    public function getClients($client_reference_id, $month, $year) {

        $clients = DB::table('clients')
                        ->where('client_reference_id', $client_reference_id)
                        ->get()
                        ->take(2)
                        ->map(function($client) use($month, $year){
                            $client->incomes = DB::table('budget')
                                                ->where('client_id', $client->id)
                                                ->where('income_expenses_type', 1)
                                                ->get()
                                                ->filter(function($income) use($month, $year){

                                                    $capture_date = explode(' ', $income->capture_date)[0];

                                                    if((explode('-', $capture_date)[0] == $year) && (explode('-', $capture_date)[1] == $month))
                                                    {
                                                        $data['id'] = $income->id;
                                                        $data['item_type'] = $income->item_type;
                                                        $data['capture_date'] = $income->capture_date;
                                                        $data['client_type'] = $income->client_type;
                                                        $data['item_id'] = $income->item_id;
                                                        return $data;

                                                    }
                                                                                                   
                                                })->values();

                            $client->expenses = DB::table('budget')
                            ->where('client_id', $client->id)
                            ->where('income_expenses_type', 2)
                            ->get()
                            ->filter(function($expense) use($month, $year){

                                $capture_date = explode(' ', $expense->capture_date)[0];

                                if((explode('-', $capture_date)[0] == $year) && (explode('-', $capture_date)[1] == $month))
                                {
                                    $data['id'] = $expense->id;
                                    $data['item_type'] = $expense->item_type;
                                    $data['capture_date'] = $expense->capture_date;
                                    $data['client_type'] = $expense->client_type;
    
                                    return $data;
                                }
                            })->values();

                            return $client;
                        });
        

        return response()->json(['clients' => $clients],201);
    }

    public function getCashflowCategories() {
        $income_types = DB::table('income_expense_type')->where('income_expense_type','1')->get();
        $expense_types = DB::table('income_expense_type')->where('income_expense_type','2')->get();

        return response()->json(['income_types' => $income_types, 'expense_types' => $expense_types], 201);
    }

    public function getCashflowNames() {

        $income_names = DB::select('SELECT income_expense_type_items.id, income_expense_type_items.income_expense_id, income_expense_type_items.item_name 
                                    FROM `income_expense_type` 
                                    LEFT JOIN `income_expense_type_items` ON income_expense_type.id = income_expense_type_items.income_expense_id 
                                    WHERE `income_expense_type` = 1 
                                    ORDER BY `income_expense_name` DESC');
                                    
        $expense_names = DB::select('SELECT income_expense_type_items.id, income_expense_type_items.income_expense_id, income_expense_type_items.item_name 
                                    FROM `income_expense_type` 
                                    LEFT JOIN `income_expense_type_items` ON income_expense_type.id = income_expense_type_items.income_expense_id 
                                    WHERE `income_expense_type` = 2 
                                    ORDER BY `income_expense_name` DESC');

        return response()->json(['income_names' => $income_names, 'expense_names' => $expense_names], 201);

    }

    public function updateClientCashflow(Request $request, $client_reference_id, $month, $year)
    {
       
        $clients = $request->all();


        foreach($clients as $client)
        {
          
            $clientObj = DB::table('clients')->where('id', $client['id'])->first();

           DB::table('budget')->where('client_id', $client['id'])->get()
                        ->filter(function($budget) use($month, $year){

                             $capture_date = explode(' ', $budget->capture_date)[0];

                            if((explode('-', $capture_date)[0] == $year) && (explode('-', $capture_date)[1] == $month))
                            {
                                return $budget;
                            }

                        })->each(function($item) {
                            DB::table('budget')->where('id', $item->id)->delete();
                        });
      
            DB::table('yearly_budget')->where('client_id', $client['id'])->get()
            ->filter(function($yearly_budget) use($month, $year){

                    $capture_date = explode(' ', $yearly_budget->capture_date)[0];

                if((explode('-', $capture_date)[0] == $year) && (explode('-', $capture_date)[1] == $month))
                {
                    return $yearly_budget;
                }

            })->each(function($item) {
                DB::table('budget')->where('id', $item->id)->delete();
            });
            
            foreach($client['incomes'] as $income)
            {

                $budget_id = DB::table('budget')->insert([
                    'client_reference_id' => $clientObj->client_reference_id,
                    'advisor_id' => $clientObj->advisor_id,
                    'client_id' => $clientObj->id,
                    'client_type' => $clientObj->client_type,
                    'advisor_capture_id' => $clientObj->advisor_id,
                    'income_expenses_type' => 1,
                    'item_type_id' => $income['item_id'],
                    'item_type' => DB::table('income_expense_type')->where('id', $income['item_id'])->first()->income_expense_name,
                    'item_id' => $income['item_id'],
                    'item_name' => $income['item_name'],
                    'item_value' => $income['item_value'],
                    'capture_date' => \Carbon\Carbon::createFromFormat('d.m.Y H:i:s', "01.$month.$year 00:00:00")
                ]);
                
                DB::table('yearly_budget')->insert([
                    'client_reference_id' => $clientObj->client_reference_id,
                    'advisor_id' => $clientObj->advisor_id,
                    'advisor_capture_id' => $clientObj->advisor_id,
                    'budget_id' => $budget_id,
                    'client_id' => $clientObj->id,
                    'client_type' => $clientObj->client_type,
                    'income_expenses_type' => 1,
                    'item_type_id' => $income['item_id'],
                    'item_type' => DB::table('income_expense_type')->where('id', $income['item_id'])->first()->income_expense_name,
                    'item_id' => $income['item_id'],
                    'item_name' => $income['item_name'],
                    'item_value' => $income['item_value'],
                    'month' => $month,
                    'year' => $year,
                    'capture_date' => \Carbon\Carbon::createFromFormat('d.m.Y H:i:s', "01.$month.$year 00:00:00")
                ]);
            }

            foreach($client['expenses'] as $expense)
            {

                $budget_id = DB::table('budget')->insert([
                    'client_reference_id' => $clientObj->client_reference_id,
                    'advisor_id' => $clientObj->advisor_id,
                    'client_id' => $clientObj->id,
                    'client_type' => $clientObj->client_type,
                    'advisor_capture_id' => $clientObj->advisor_id,
                    'income_expenses_type' => 2,
                    'item_type_id' => $expense['item_id'],
                    'item_type' => DB::table('income_expense_type')->where('id', $expense['item_id'])->first()->income_expense_name,
                    'item_id' => $expense['item_id'],
                    'item_name' => $expense['item_name'],
                    'item_value' => $expense['item_value'],
                    'capture_date' => \Carbon\Carbon::createFromFormat('d.m.Y H:i:s', "01.$month.$year 00:00:00")
                ]);
                
                DB::table('yearly_budget')->insert([
                    'client_reference_id' => $clientObj->client_reference_id,
                    'advisor_id' => $clientObj->advisor_id,
                    'advisor_capture_id' => $clientObj->advisor_id,
                    'budget_id' => $budget_id,
                    'client_id' => $clientObj->id,
                    'client_type' => $clientObj->client_type,
                    'income_expenses_type' => 2,
                    'item_type_id' => $expense['item_id'],
                    'item_type' => DB::table('income_expense_type')->where('id', $expense['item_id'])->first()->income_expense_name,
                    'item_id' => $expense['item_id'],
                    'item_name' => $expense['item_name'],
                    'item_value' => $expense['item_value'],
                    'month' => $month,
                    'year' => $year,
                    'capture_date' => \Carbon\Carbon::createFromFormat('d.m.Y H:i:s', "01.$month.$year 00:00:00")
                ]);
            }
            
        }

        return response()->json(['message' => 'success'], 201);
    }

    public function cpbCreditScore(Request $request)
    {
        $userId = $request->user_id;
        $id_number = $request->id_number;
        $client_type = $request->client_type;
        $client_reference_id = $request->client_reference_id;

        DB::table('credit_score_enquiry')->insert([
            'advisor_id' => $userId,
            'capture_advisor_id' => $userId,
            'client_reference_id' =>  $client_reference_id,
            'client_type' => $client_type,
            'id_number' => $id_number,
            'account_number' => '00001',
            'amount' => '100',
            'date' => Date::now()
        ]);
        
        return response()->json(['status' => 'success'], 201);
    }
}
